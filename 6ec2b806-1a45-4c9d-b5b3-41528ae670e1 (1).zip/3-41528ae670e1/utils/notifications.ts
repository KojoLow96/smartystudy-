
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LS_REMINDER = '@smartstudy/reminder';

export type ReminderSettings = {
  enabled: boolean;
  hour: number;
  minute: number;
};

export async function registerNotifications() {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== 'granted') {
    console.log('Notifications permission not granted');
    return false;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Default',
      importance: Notifications.AndroidImportance.DEFAULT,
      sound: 'default',
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
      bypassDnd: false,
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    });
  }
  return true;
}

export async function scheduleDailyReminder(hour: number, minute: number) {
  const permission = await registerNotifications();
  if (!permission) return null;

  // Cancel old reminders first for safety
  await Notifications.cancelAllScheduledNotificationsAsync();

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'SmartStudy Reminder',
      body: 'Time to study! Keep your streak and make progress today.',
      sound: 'default',
    },
    trigger: {
      hour,
      minute,
      repeats: true,
      channelId: 'default',
    } as any,
  });

  const settings: ReminderSettings = { enabled: true, hour, minute };
  await AsyncStorage.setItem(LS_REMINDER, JSON.stringify(settings));
  return id;
}

export async function cancelAllReminders() {
  await Notifications.cancelAllScheduledNotificationsAsync();
  const settings: ReminderSettings = { enabled: false, hour: 19, minute: 0 };
  await AsyncStorage.setItem(LS_REMINDER, JSON.stringify(settings));
}

export async function loadReminderSettings(): Promise<ReminderSettings> {
  try {
    const raw = await AsyncStorage.getItem(LS_REMINDER);
    if (!raw) return { enabled: false, hour: 19, minute: 0 };
    return JSON.parse(raw) as ReminderSettings;
  } catch (e) {
    console.log('loadReminderSettings error', e);
    return { enabled: false, hour: 19, minute: 0 };
  }
}
