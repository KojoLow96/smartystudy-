
import { CourseId } from '../types/course';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type QuizQuestion = {
  id: string;
  course: CourseId;
  prompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint?: string;
  difficulty: Difficulty;
};

function qid(course: CourseId, idx: number) {
  return `${course}-${idx}`;
}

export const quizBank: Record<CourseId, QuizQuestion[]> = {
  mathematics: [
    {
      id: qid('mathematics', 1),
      course: 'mathematics',
      prompt: 'What is 12 × 8?',
      options: ['96', '100', '88', '108'],
      correctIndex: 0,
      explanation: '12 times 8 equals 96. You can compute it as (10×8) + (2×8) = 80 + 16 = 96.',
      hint: 'Break it down: 10×8 + 2×8.',
      difficulty: 'easy',
    },
    {
      id: qid('mathematics', 2),
      course: 'mathematics',
      prompt: 'What is the derivative of x^2?',
      options: ['2x', 'x', 'x^3', '1'],
      correctIndex: 0,
      explanation: 'Power rule: d/dx x^n = n·x^(n-1). For n=2, derivative is 2x.',
      hint: 'Use the power rule.',
      difficulty: 'easy',
    },
    {
      id: qid('mathematics', 3),
      course: 'mathematics',
      prompt: 'π is approximately?',
      options: ['2.14', '3.14', '3.41', '3.04'],
      correctIndex: 1,
      explanation: 'π ≈ 3.14159. Rounded to two decimals it is 3.14.',
      hint: 'Commonly memorized as 3.14.',
      difficulty: 'easy',
    },
    {
      id: qid('mathematics', 4),
      course: 'mathematics',
      prompt: 'Solve for x: 2x + 5 = 17.',
      options: ['6', '5', '7', '12'],
      correctIndex: 0,
      explanation: '2x = 12 so x = 6.',
      hint: 'Subtract 5 from both sides first.',
      difficulty: 'easy',
    },
    {
      id: qid('mathematics', 5),
      course: 'mathematics',
      prompt: 'The integral of 2x dx is:',
      options: ['x^2 + C', 'x + C', 'x^3 + C', '2 + C'],
      correctIndex: 0,
      explanation: '∫2x dx = x^2 + C by reverse power rule.',
      hint: 'Reverse the derivative of x^2.',
      difficulty: 'medium',
    },
    {
      id: qid('mathematics', 6),
      course: 'mathematics',
      prompt: 'What is the discriminant of ax^2 + bx + c = 0?',
      options: ['b^2 - 4ac', 'b^2 + 4ac', '4ac - b^2', '2ab + c'],
      correctIndex: 0,
      explanation: 'Discriminant Δ = b^2 - 4ac.',
      hint: 'Appears under the square root in the quadratic formula.',
      difficulty: 'medium',
    },
    {
      id: qid('mathematics', 7),
      course: 'mathematics',
      prompt: 'Limit: lim(x→0) (sin x)/x = ?',
      options: ['0', '1', '∞', 'Does not exist'],
      correctIndex: 1,
      explanation: 'A standard limit from calculus: lim(sin x)/x = 1.',
      hint: 'Famous standard limit.',
      difficulty: 'hard',
    },
  ],
  science: [
    {
      id: qid('science', 1),
      course: 'science',
      prompt: 'Water chemical formula?',
      options: ['H2O', 'CO2', 'O2', 'NaCl'],
      correctIndex: 0,
      explanation: 'Water is H2O: two hydrogen atoms and one oxygen atom.',
      hint: 'Two hydrogens and one oxygen.',
      difficulty: 'easy',
    },
    {
      id: qid('science', 2),
      course: 'science',
      prompt: 'Earth is the ___ planet from the Sun.',
      options: ['2nd', '3rd', '4th', '5th'],
      correctIndex: 1,
      explanation: 'Mercury (1st), Venus (2nd), Earth (3rd).',
      hint: 'Mercury, Venus, then Earth.',
      difficulty: 'easy',
    },
    {
      id: qid('science', 3),
      course: 'science',
      prompt: 'Photosynthesis occurs in the...',
      options: ['Nucleus', 'Chloroplast', 'Mitochondria', 'Ribosome'],
      correctIndex: 1,
      explanation: 'Photosynthesis happens in chloroplasts of plant cells.',
      hint: 'Plant cells have a special green organelle.',
      difficulty: 'easy',
    },
    {
      id: qid('science', 4),
      course: 'science',
      prompt: 'Which gas is primarily responsible for the greenhouse effect?',
      options: ['Nitrogen', 'Oxygen', 'Carbon Dioxide', 'Helium'],
      correctIndex: 2,
      explanation: 'CO2 is a key greenhouse gas contributing to warming.',
      hint: 'It is emitted by fossil fuel burning.',
      difficulty: 'medium',
    },
    {
      id: qid('science', 5),
      course: 'science',
      prompt: 'Mitochondria are known as the...',
      options: ['Brain of the cell', 'Powerhouse of the cell', 'Skeleton of the cell', 'Skin of the cell'],
      correctIndex: 1,
      explanation: 'Mitochondria generate ATP, hence “powerhouse of the cell”.',
      hint: 'Energy production.',
      difficulty: 'medium',
    },
    {
      id: qid('science', 6),
      course: 'science',
      prompt: 'pH < 7 indicates a(n)...',
      options: ['Neutral solution', 'Acidic solution', 'Basic solution', 'Salty solution'],
      correctIndex: 1,
      explanation: 'pH < 7 is acidic, pH = 7 neutral, pH > 7 basic/alkaline.',
      hint: 'Think of vinegar or lemon juice.',
      difficulty: 'hard',
    },
  ],
  history: [
    {
      id: qid('history', 1),
      course: 'history',
      prompt: 'Who was the first President of the US?',
      options: ['Abraham Lincoln', 'Thomas Jefferson', 'George Washington', 'John Adams'],
      correctIndex: 2,
      explanation: 'George Washington served from 1789 to 1797.',
      hint: 'Known as the “Father of His Country”.',
      difficulty: 'easy',
    },
    {
      id: qid('history', 2),
      course: 'history',
      prompt: 'The Renaissance began in which country?',
      options: ['France', 'Italy', 'Spain', 'Germany'],
      correctIndex: 1,
      explanation: 'The Italian Renaissance started in the 14th century in Italy.',
      hint: 'Florence and Venice were key cities.',
      difficulty: 'easy',
    },
    {
      id: qid('history', 3),
      course: 'history',
      prompt: 'Which war ended in 1945?',
      options: ['World War I', 'World War II', 'Cold War', 'Korean War'],
      correctIndex: 1,
      explanation: 'World War II ended in 1945.',
      hint: 'It followed the 1939–1945 period.',
      difficulty: 'easy',
    },
    {
      id: qid('history', 4),
      course: 'history',
      prompt: 'The Magna Carta was signed in...',
      options: ['1066', '1215', '1492', '1776'],
      correctIndex: 1,
      explanation: 'Signed in 1215, it limited the power of the English monarch.',
      hint: 'Early 13th century.',
      difficulty: 'medium',
    },
    {
      id: qid('history', 5),
      course: 'history',
      prompt: 'Which empire built the Colosseum?',
      options: ['Greek Empire', 'Roman Empire', 'Persian Empire', 'Ottoman Empire'],
      correctIndex: 1,
      explanation: 'The Roman Empire built the Colosseum in Rome.',
      hint: 'Located in Rome.',
      difficulty: 'medium',
    },
    {
      id: qid('history', 6),
      course: 'history',
      prompt: 'The Treaty of Versailles primarily ended which conflict?',
      options: ['Napoleonic Wars', 'World War I', 'World War II', 'Thirty Years’ War'],
      correctIndex: 1,
      explanation: 'The Treaty of Versailles (1919) ended World War I.',
      hint: '1919 peace treaty.',
      difficulty: 'hard',
    },
  ],
};

export function getQuestionsForCourse(course: CourseId): QuizQuestion[] {
  return quizBank[course] || [];
}
