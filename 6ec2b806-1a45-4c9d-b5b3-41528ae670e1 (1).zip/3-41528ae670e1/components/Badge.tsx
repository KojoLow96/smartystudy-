
import React, { memo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../styles/commonStyles';

type Props = {
  title: string;
  description?: string;
};

function BadgeInner({ title, description }: Props) {
  return (
    <View style={styles.badge}>
      <Text style={styles.title}>{title}</Text>
      {description ? <Text style={styles.desc}>{description}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    backgroundColor: '#E3F2FD',
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 8,
    boxShadow: '0px 1px 3px rgba(0,0,0,0.08)',
  },
  title: {
    color: colors.text,
    fontWeight: '800',
    marginBottom: 4,
  },
  desc: {
    color: '#607D8B',
    fontSize: 12,
  },
});

export default memo(BadgeInner);
