
import React, { memo, useMemo } from 'react';
import Svg, { Circle } from 'react-native-svg';
import { View } from 'react-native';
import { colors } from '../styles/commonStyles';

type Props = {
  size?: number;
  strokeWidth?: number;
  progress: number; // 0..1
};

function ProgressDonutInner({ size = 60, strokeWidth = 8, progress }: Props) {
  const { radius, circumference, strokeDashoffset } = useMemo(() => {
    const r = (size - strokeWidth) / 2;
    const c = 2 * Math.PI * r;
    const clamped = Math.max(0, Math.min(1, progress));
    const sdo = c * (1 - clamped);
    return { radius: r, circumference: c, strokeDashoffset: sdo };
  }, [size, strokeWidth, progress]);

  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#E0E0E0"
          strokeWidth={strokeWidth}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={colors.primary}
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference}`}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          fill="none"
        />
      </Svg>
    </View>
  );
}

export default memo(ProgressDonutInner);
