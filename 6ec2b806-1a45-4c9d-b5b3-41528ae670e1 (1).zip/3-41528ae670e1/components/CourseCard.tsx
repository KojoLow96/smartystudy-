
import React, { memo } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import Icon from './Icon';
import { colors, commonStyles } from '../styles/commonStyles';

type Props = {
  title: string;
  subtitle?: string;
  iconName?: any;
  onOpenNotes: () => void;
  onOpenQuiz: () => void;
};

function CourseCardInner({ title, subtitle, onOpenNotes, onOpenQuiz, iconName }: Props) {
  return (
    <View
      style={{
        backgroundColor: colors.card,
        borderRadius: 14,
        padding: 16,
        marginVertical: 8,
        boxShadow: '0px 4px 16px rgba(0,0,0,0.06)',
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
        <Icon name={iconName || 'book-outline'} size={28} color={colors.secondary} />
        <Text style={[commonStyles.title, { marginLeft: 10, flex: 1, textAlign: 'left' }]}>{title}</Text>
      </View>
      {subtitle ? (
        <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 12, color: colors.grey }]}>{subtitle}</Text>
      ) : null}

      <View style={{ flexDirection: 'row', gap: 10 }}>
        <TouchableOpacity
          onPress={onOpenNotes}
          style={{
            flex: 1,
            padding: 12,
            borderRadius: 10,
            backgroundColor: colors.primary,
            alignItems: 'center',
            boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
          }}
        >
          <Text style={{ color: 'white', fontWeight: '700' }}>Open Notes</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={onOpenQuiz}
          style={{
            flex: 1,
            padding: 12,
            borderRadius: 10,
            backgroundColor: colors.backgroundAlt,
            alignItems: 'center',
            boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
          }}
        >
          <Text style={{ color: colors.text, fontWeight: '700' }}>Take Quiz</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const CourseCard = memo(CourseCardInner);
export default CourseCard;
