
import { CourseId } from './course';

export type TextBlock = {
  type: 'text';
  text: string;
};

export type ImageBlock = {
  type: 'image';
  url: string;
  name?: string;
};

export type FileBlock = {
  type: 'file';
  url: string;
  name?: string;
};

export type ContentBlock = TextBlock | ImageBlock | FileBlock;

export type Note = {
  id: string;
  course: CourseId;
  topic?: string; // optional: when viewing a specific topic within a course
  blocks: ContentBlock[];
  updated_at: string;
};
