
export type CourseId = 'mathematics' | 'science' | 'history';

export type Course = {
  id: CourseId;
  name: string;
  icon: any;
};

export type CourseTopic = {
  key: string;      // normalized key for routing/query
  title: string;    // display title
  section: string;  // category/section display
};

export const courses: Course[] = [
  { id: 'mathematics', name: 'Mathematics', icon: 'calculator-outline' },
  { id: 'science', name: 'Science', icon: 'flask-outline' },
  { id: 'history', name: 'History', icon: 'library-outline' },
];

export const courseById = (id: string): Course => {
  switch (id) {
    case 'mathematics':
      return courses[0];
    case 'science':
      return courses[1];
    case 'history':
      return courses[2];
    default:
      return courses[0];
  }
};

export function getTopicsForCourse(course: CourseId): CourseTopic[] {
  switch (course) {
    case 'mathematics':
      return [
        // Algebra
        { key: 'variables', title: 'Variables', section: 'Algebra' },
        { key: 'equations', title: 'Equations', section: 'Algebra' },
        { key: 'factoring', title: 'Factoring', section: 'Algebra' },
        { key: 'linear-functions', title: 'Linear Functions', section: 'Algebra' },
        { key: 'quadratic-functions', title: 'Quadratic Functions', section: 'Algebra' },
        // Geometry
        { key: 'angles', title: 'Angles', section: 'Geometry' },
        { key: 'triangles', title: 'Triangles', section: 'Geometry' },
        { key: 'circles', title: 'Circles', section: 'Geometry' },
        { key: 'area', title: 'Area', section: 'Geometry' },
        { key: 'perimeter', title: 'Perimeter', section: 'Geometry' },
        { key: 'volume', title: 'Volume', section: 'Geometry' },
        // Calculus
        { key: 'limits', title: 'Limits', section: 'Calculus' },
        { key: 'derivatives', title: 'Derivatives', section: 'Calculus' },
        { key: 'integrals', title: 'Integrals', section: 'Calculus' },
        { key: 'applications', title: 'Applications', section: 'Calculus' },
      ];
    case 'science':
      return [
        // Physics
        { key: 'motion', title: 'Motion', section: 'Physics' },
        { key: 'forces', title: 'Forces', section: 'Physics' },
        { key: 'energy', title: 'Energy', section: 'Physics' },
        { key: 'waves', title: 'Waves', section: 'Physics' },
        { key: 'electricity', title: 'Electricity', section: 'Physics' },
        // Chemistry
        { key: 'atoms', title: 'Atoms', section: 'Chemistry' },
        { key: 'molecules', title: 'Molecules', section: 'Chemistry' },
        { key: 'reactions', title: 'Reactions', section: 'Chemistry' },
        { key: 'acids-bases', title: 'Acids & Bases', section: 'Chemistry' },
        // Biology
        { key: 'cells', title: 'Cells', section: 'Biology' },
        { key: 'genetics', title: 'Genetics', section: 'Biology' },
        { key: 'evolution', title: 'Evolution', section: 'Biology' },
        { key: 'ecosystems', title: 'Ecosystems', section: 'Biology' },
        { key: 'anatomy', title: 'Anatomy', section: 'Biology' },
      ];
    case 'history':
      return [
        // Ancient
        { key: 'mesopotamia', title: 'Mesopotamia', section: 'Ancient' },
        { key: 'ancient-egypt', title: 'Ancient Egypt', section: 'Ancient' },
        { key: 'ancient-greece', title: 'Ancient Greece', section: 'Ancient' },
        { key: 'ancient-rome', title: 'Ancient Rome', section: 'Ancient' },
        // Middle Ages
        { key: 'feudalism', title: 'Feudalism', section: 'Middle Ages' },
        { key: 'crusades', title: 'Crusades', section: 'Middle Ages' },
        { key: 'cultural-exchange', title: 'Cultural Exchange', section: 'Middle Ages' },
        // Modern
        { key: 'revolutions', title: 'Revolutions', section: 'Modern' },
        { key: 'world-wars', title: 'World Wars', section: 'Modern' },
        { key: 'globalization', title: 'Globalization', section: 'Modern' },
        { key: 'technology', title: 'Technology', section: 'Modern' },
      ];
    default:
      return [];
  }
}
