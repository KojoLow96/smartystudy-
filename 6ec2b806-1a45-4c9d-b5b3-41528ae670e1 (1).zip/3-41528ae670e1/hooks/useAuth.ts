
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '../app/integrations/supabase/client';
import { Alert } from 'react-native';

export type AuthState = {
  loading: boolean;
  userId: string | null;
  email: string | null;
};

export function useAuth() {
  const [state, setState] = useState<AuthState>({ loading: true, userId: null, email: null });

  useEffect(() => {
    let mounted = true;

    async function init() {
      try {
        const { data } = await supabase.auth.getSession();
        if (!mounted) return;
        if (data.session?.user) {
          setState({
            loading: false,
            userId: data.session.user.id,
            email: data.session.user.email ?? null,
          });
        } else {
          setState({ loading: false, userId: null, email: null });
        }
      } catch (e) {
        console.log('useAuth init error', e);
        setState({ loading: false, userId: null, email: null });
      }
    }

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      if (session?.user) {
        setState({
          loading: false,
          userId: session.user.id,
          email: session.user.email ?? null,
        });
      } else {
        setState({ loading: false, userId: null, email: null });
      }
    });

    init();

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const signOut = useCallback(async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        Alert.alert('Logout failed', error.message || 'Please try again.');
      } else {
        Alert.alert('Logged out', 'You have been signed out.');
      }
    } catch (e: any) {
      console.log('signOut error', e);
      Alert.alert('Logout failed', e?.message || 'Please try again.');
    }
  }, []);

  return {
    ...state,
    signOut,
  };
}
