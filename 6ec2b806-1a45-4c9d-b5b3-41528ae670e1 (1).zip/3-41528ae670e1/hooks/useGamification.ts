
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../app/integrations/supabase/client';
import { CourseId } from '../types/course';
import { isSupabaseAvailable } from '../app/integrations/supabase/ping';

export type Mode = 'normal' | 'daily';

export type LocalAnswer = {
  questionId: string;
  selectedIndex: number | null;
  correctIndex: number;
  correct: boolean;
};

export type LocalSession = {
  id: string;
  userId: string | null;
  course: CourseId;
  mode: Mode;
  answers: LocalAnswer[];
  score: number;
  total: number;
  accuracy: number; // 0..1
  startedAt: string;
  finishedAt?: string | null;
};

export type Achievement = {
  key: string;
  title: string;
  description: string;
  points: number;
  unlockedAt: string;
};

export type LeaderboardRow = {
  user_id: string;
  points: number;
};

const LS_PREFIX = '@smartstudy/gamification/';
const LS_POINTS = `${LS_PREFIX}points`;
const LS_ACHV = `${LS_PREFIX}achievements`;
const LS_SESSIONS = `${LS_PREFIX}sessions`;

async function loadJSON<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (e) {
    console.log('loadJSON error', key, e);
    return fallback;
  }
}

async function saveJSON<T>(key: string, data: T) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.log('saveJSON error', key, e);
  }
}

export function useGamification(userId?: string | null) {
  const [supabaseConfigured, setSupabaseConfigured] = useState(false);
  const [points, setPoints] = useState<number>(0);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [sessions, setSessions] = useState<LocalSession[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardRow[]>([]);
  const [loading, setLoading] = useState(false);
  const currentSessionRef = useRef<LocalSession | null>(null);

  useEffect(() => {
    (async () => {
      const ok = await isSupabaseAvailable();
      setSupabaseConfigured(ok);
    })();
  }, []);

  useEffect(() => {
    (async () => {
      const p = await loadJSON<number>(LS_POINTS, 0);
      const a = await loadJSON<Achievement[]>(LS_ACHV, []);
      const s = await loadJSON<LocalSession[]>(LS_SESSIONS, []);
      setPoints(p);
      setAchievements(a);
      setSessions(s);
    })();
  }, []);

  const addLocalPoints = useCallback(async (delta: number) => {
    const next = Math.max(0, points + delta);
    setPoints(next);
    await saveJSON(LS_POINTS, next);
  }, [points]);

  const unlockAchievementLocal = useCallback(async (ach: Achievement) => {
    const exists = achievements.some(x => x.key === ach.key);
    if (exists) return;
    const next = [...achievements, ach];
    setAchievements(next);
    await saveJSON(LS_ACHV, next);
  }, [achievements]);

  const syncPointsRemote = useCallback(async (newPoints: number) => {
    if (!supabaseConfigured || !userId) return;
    try {
      // upsert user_points
      const { error } = await supabase
        .from('user_points')
        .upsert([{ user_id: userId, points: newPoints } as any], { onConflict: 'user_id' as any });
      if (error) console.log('syncPointsRemote error', error.message);
    } catch (e) {
      console.log('syncPointsRemote exception', e);
    }
  }, [supabaseConfigured, userId]);

  const syncAchievementRemote = useCallback(async (ach: Achievement) => {
    if (!supabaseConfigured || !userId) return;
    try {
      const { error } = await supabase
        .from('achievements')
        .insert([{ user_id: userId, key: ach.key, title: ach.title, description: ach.description, points: ach.points, unlocked_at: ach.unlockedAt } as any]);
      if (error) console.log('syncAchievementRemote error', error.message);
    } catch (e) {
      console.log('syncAchievementRemote exception', e);
    }
  }, [supabaseConfigured, userId]);

  const startSession = useCallback(async (course: CourseId, mode: Mode = 'normal') => {
    const now = new Date().toISOString();
    const local: LocalSession = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      userId: userId || null,
      course,
      mode,
      answers: [],
      score: 0,
      total: 0,
      accuracy: 0,
      startedAt: now,
      finishedAt: null,
    };
    currentSessionRef.current = local;

    if (supabaseConfigured && userId) {
      try {
        const { data, error } = await supabase
          .from('quiz_sessions')
          .insert([{ user_id: userId, course, mode, score: 0, total: 0, accuracy: 0 } as any])
          .select('*')
          .maybeSingle();
        if (error) {
          console.log('startSession remote error', error.message);
        } else if (data) {
          local.id = (data as any).id;
        }
      } catch (e) {
        console.log('startSession remote exception', e);
      }
    }

    setSessions(prev => [local, ...prev]);
    await saveJSON(LS_SESSIONS, [local, ...sessions]);
    return local.id;
  }, [userId, supabaseConfigured, sessions]);

  const recordAnswer = useCallback(async (payload: LocalAnswer) => {
    if (!currentSessionRef.current) return;
    const sess = { ...currentSessionRef.current };
    sess.answers = [...sess.answers, payload];
    const correctCount = sess.answers.filter(a => a.correct).length;
    sess.total = sess.answers.length;
    sess.score = correctCount * 10;
    sess.accuracy = sess.total > 0 ? correctCount / sess.total : 0;
    currentSessionRef.current = sess;

    setSessions(prev => {
      const idx = prev.findIndex(s => s.id === sess.id);
      if (idx >= 0) {
        const copy = prev.slice();
        copy[idx] = sess;
        saveJSON(LS_SESSIONS, copy);
        return copy;
      }
      const next = [sess, ...prev];
      saveJSON(LS_SESSIONS, next);
      return next;
    });

    if (supabaseConfigured && userId) {
      try {
        const { error } = await supabase
          .from('quiz_answers')
          .insert([{ session_id: sess.id, question_id: payload.questionId, selected_index: payload.selectedIndex, correct_index: payload.correctIndex, correct: payload.correct } as any]);
        if (error) console.log('recordAnswer remote error', error.message);
      } catch (e) {
        console.log('recordAnswer remote exception', e);
      }
      try {
        const { error } = await supabase
          .from('quiz_sessions')
          .update({ score: sess.score, total: sess.total, accuracy: sess.accuracy })
          .eq('id', sess.id);
        if (error) console.log('update session stats error', error.message);
      } catch (e) {
        console.log('update session stats exception', e);
      }
    }
  }, [userId, supabaseConfigured]);

  const finishSession = useCallback(async () => {
    const sess = currentSessionRef.current;
    if (!sess) return { pointsEarned: 0, unlocked: [] as Achievement[] };
    sess.finishedAt = new Date().toISOString();
    currentSessionRef.current = null;

    // Award points: 10 per correct + accuracy bonus
    const correct = sess.answers.filter(a => a.correct).length;
    const base = correct * 10;
    const bonus = sess.accuracy >= 0.8 ? 10 : 0;
    const earned = base + bonus;

    await addLocalPoints(earned);
    await syncPointsRemote(points + earned);

    const unlocked: Achievement[] = [];
    // Simple achievements
    if (!achievements.some(a => a.key === 'first_quiz')) {
      const ach: Achievement = {
        key: 'first_quiz',
        title: 'First Steps',
        description: 'Completed your first quiz.',
        points: 10,
        unlockedAt: new Date().toISOString(),
      };
      await unlockAchievementLocal(ach);
      await syncAchievementRemote(ach);
      unlocked.push(ach);
    }
    if (sess.accuracy >= 0.8 && !achievements.some(a => a.key === 'accuracy_80')) {
      const ach: Achievement = {
        key: 'accuracy_80',
        title: 'Sharp Mind',
        description: 'Achieved 80% or higher accuracy in a quiz.',
        points: 20,
        unlockedAt: new Date().toISOString(),
      };
      await unlockAchievementLocal(ach);
      await syncAchievementRemote(ach);
      unlocked.push(ach);
    }

    // Persist session finalization and remote sync
    setSessions(prev => {
      const idx = prev.findIndex(s => s.id === sess.id);
      if (idx >= 0) {
        const copy = prev.slice();
        copy[idx] = sess;
        saveJSON(LS_SESSIONS, copy);
        return copy;
      }
      const next = [sess, ...prev];
      saveJSON(LS_SESSIONS, next);
      return next;
    });

    if (supabaseConfigured && userId) {
      try {
        const { error } = await supabase
          .from('quiz_sessions')
          .update({ finished_at: sess.finishedAt, score: sess.score, total: sess.total, accuracy: sess.accuracy })
          .eq('id', sess.id);
        if (error) console.log('finishSession remote error', error.message);
      } catch (e) {
        console.log('finishSession remote exception', e);
      }
    }

    return { pointsEarned: earned, unlocked };
  }, [addLocalPoints, achievements, points, supabaseConfigured, syncAchievementRemote, syncPointsRemote, userId]);

  const fetchLeaderboard = useCallback(async () => {
    setLoading(true);
    try {
      if (supabaseConfigured) {
        const { data, error } = await supabase
          .from('user_points')
          .select('*')
          .order('points', { ascending: false } as any)
          .limit(20);
        if (error) {
          console.log('fetchLeaderboard error', error.message);
          setLeaderboard([]);
        } else {
          setLeaderboard((data as any[]).map(d => ({ user_id: d.user_id, points: d.points })));
        }
      } else {
        setLeaderboard([]);
      }
    } finally {
      setLoading(false);
    }
  }, [supabaseConfigured]);

  // Personalized topic recommendation based on recent sessions
  const recommendNextTopic = useCallback((course: CourseId): string => {
    // If no sessions, suggest an intro topic
    const recent = sessions.filter(s => s.course === course).slice(0, 5);
    if (recent.length === 0) return 'Start with basics in this course.';
    // Find weakest area from the last session by looking at incorrect answers prompt keywords
    const last = recent[0];
    const incorrectIds = last.answers.filter(a => !a.correct).map(a => a.questionId);
    if (incorrectIds.length === 0) return 'Advance to a harder topic — great accuracy!';
    const hintMap: Record<CourseId, Record<string, string>> = {
      mathematics: {
        'mathematics-5': 'Try reviewing Integrals.',
        'mathematics-6': 'Revisit Quadratics and Discriminants.',
        'mathematics-7': 'Review standard limits in Calculus.',
        'mathematics-1': 'Brush up on Arithmetic basics.',
        'mathematics-2': 'Practice Derivatives.',
        'mathematics-4': 'Review simple linear equations.',
        'mathematics-3': 'Memorize common constants like π.',
      },
      science: {
        'science-4': 'Review Greenhouse gases and climate basics.',
        'science-5': 'Revisit cell energy (Mitochondria).',
        'science-6': 'Study pH scale and acidity.',
        'science-1': 'Review Chemistry symbols.',
        'science-2': 'Study planetary order.',
        'science-3': 'Review Photosynthesis in chloroplasts.',
      },
      history: {
        'history-4': 'Review Magna Carta and Medieval England.',
        'history-5': 'Read Roman Empire highlights.',
        'history-6': 'Study WWI and the Treaty of Versailles.',
        'history-1': 'Study early US presidents.',
        'history-2': 'Explore origins of the Renaissance.',
        'history-3': 'Review WWII timeline.',
      },
    };
    for (const id of incorrectIds) {
      const hint = hintMap[course][id];
      if (hint) return hint;
    }
    return 'Focus on topics you missed in the previous quiz.';
  }, [sessions]);

  return {
    loading,
    supabaseConfigured,
    points,
    achievements,
    leaderboard,
    sessions,
    // actions
    startSession,
    recordAnswer,
    finishSession,
    fetchLeaderboard,
    // personalization
    recommendNextTopic,
  };
}
