
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../app/integrations/supabase/client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Note, ContentBlock } from '../types/note';
import { CourseId } from '../types/course';
import { isSupabaseAvailable } from '../app/integrations/supabase/ping';

const STORAGE_PREFIX = '@smartstudy/notes/';

async function fetchBlob(uri: string) {
  const res = await fetch(uri);
  const blob = await res.blob();
  return blob;
}

function normalizeTopicKey(topic?: string | null): string | null {
  if (!topic) return null;
  return topic.toString().trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

function defaultNoteFor(course: CourseId): Note {
  const introMap: Record<CourseId, string[]> = {
    mathematics: [
      'Welcome to Mathematics! This course covers Algebra, Geometry, and Calculus.',
      'Algebra: Variables, equations, factoring, linear & quadratic functions.',
      'Geometry: Angles, triangles, circles, area, perimeter, and volume.',
      'Calculus: Limits, derivatives, integrals, and applications.',
    ],
    science: [
      'Welcome to Science! This course covers Physics, Chemistry, and Biology.',
      'Physics: Motion, forces, energy, waves, and electricity.',
      'Chemistry: Atoms, molecules, reactions, acids & bases.',
      'Biology: Cells, genetics, evolution, ecosystems, and anatomy.',
    ],
    history: [
      'Welcome to History! This course covers Ancient, Medieval, and Modern eras.',
      'Ancient Civilizations: Mesopotamia, Egypt, Greece, and Rome.',
      'Middle Ages: Feudalism, the Crusades, and cultural exchange.',
      'Modern History: Revolutions, world wars, globalization, and technology.',
    ],
  };
  const blocks: ContentBlock[] = introMap[course].map((t) => ({ type: 'text', text: t }));
  return {
    id: '',
    course,
    blocks,
    updated_at: new Date().toISOString(),
  };
}

function defaultNoteForTopic(course: CourseId, topicRaw: string): Note {
  const topic = normalizeTopicKey(topicRaw) || topicRaw;
  const t = (s: string) => ({ type: 'text', text: s } as ContentBlock);

  const content: Record<CourseId, Record<string, ContentBlock[]>> = {
    mathematics: {
      'variables': [
        t('Algebra • Variables'),
        t('A variable is a symbol (like x or y) that represents an unknown or changeable value.'),
        t('Examples: x + 5 = 9 (x is the variable); y - 3 = 2 (y is the variable).'),
        t('Tip: Treat variables like placeholders. Solve by isolating the variable.'),
      ],
      'equations': [
        t('Algebra • Equations'),
        t('An equation states that two expressions are equal, connected by =.'),
        t('To solve: perform inverse operations to isolate the variable on one side.'),
        t('Example: 2x + 5 = 17 → 2x = 12 → x = 6.'),
      ],
      'factoring': [
        t('Algebra • Factoring'),
        t('Factoring rewrites expressions as a product of simpler terms.'),
        t('Examples: x^2 - 9 = (x - 3)(x + 3); ax + ay = a(x + y).'),
        t('Quadratics often factor to (x - r1)(x - r2).'),
      ],
      'linear-functions': [
        t('Algebra • Linear Functions'),
        t('Linear functions have the form y = mx + b (slope m, intercept b).'),
        t('Slope m = rise/run indicates rate of change.'),
        t('Parallel lines have same slope; perpendicular slopes multiply to -1.'),
      ],
      'quadratic-functions': [
        t('Algebra • Quadratic Functions'),
        t('Quadratics have the form y = ax^2 + bx + c.'),
        t('Vertex form: y = a(x - h)^2 + k; Axis of symmetry x = h.'),
        t('Roots from factoring or quadratic formula: x = (-b ± √(b^2 - 4ac)) / (2a).'),
      ],
      'angles': [
        t('Geometry • Angles'),
        t('Types: acute (<90°), right (=90°), obtuse (>90°), straight (=180°).'),
        t('Complementary sum to 90°, supplementary sum to 180°.'),
      ],
      'triangles': [
        t('Geometry • Triangles'),
        t('Sum of interior angles is 180°.'),
        t('Pythagorean theorem (right triangles): a^2 + b^2 = c^2.'),
        t('Classify by sides (scalene, isosceles, equilateral) and angles.'),
      ],
      'circles': [
        t('Geometry • Circles'),
        t('Key terms: radius r, diameter d=2r, circumference C=2πr, area A=πr^2.'),
        t('Arcs and central angles relate proportionally to circumference.'),
      ],
      'area': [
        t('Geometry • Area'),
        t('Rect: A=lw; Triangle: A=1/2·bh; Circle: A=πr^2.'),
        t('Composite areas can be split into basic shapes.'),
      ],
      'perimeter': [
        t('Geometry • Perimeter'),
        t('Perimeter is boundary length; sum of side lengths.'),
        t('Circle perimeter is circumference C=2πr.'),
      ],
      'volume': [
        t('Geometry • Volume'),
        t('Prism/Cylinder: V=Area(base)·height; Sphere: V=4/3·πr^3; Cone: V=1/3·πr^2h.'),
      ],
      'limits': [
        t('Calculus • Limits'),
        t('A limit describes the value f(x) approaches as x approaches a point.'),
        t('Standard: lim (sin x)/x as x→0 equals 1.'),
      ],
      'derivatives': [
        t('Calculus • Derivatives'),
        t('Derivative measures instantaneous rate of change or slope.'),
        t('Power rule: d/dx x^n = n·x^(n-1).'),
      ],
      'integrals': [
        t('Calculus • Integrals'),
        t('Integral accumulates area under a curve.'),
        t('Reverse power rule: ∫ x^n dx = x^(n+1)/(n+1) + C (n≠-1).'),
      ],
      'applications': [
        t('Calculus • Applications'),
        t('Optimization: maximize/minimize with derivatives.'),
        t('Area/accumulation problems use definite integrals.'),
      ],
    },
    science: {
      // Physics
      'motion': [
        t('Physics • Motion'),
        t('Motion describes a change in position over time. Speed is distance/time, velocity adds direction, and acceleration is change in velocity per time.'),
        t('Use kinematics equations for constant acceleration, e.g., v = v0 + at, s = v0t + 1/2 at^2.'),
      ],
      'forces': [
        t('Physics • Forces'),
        t('A force is a push or pull. Newton’s 2nd law: F = m a.'),
        t('Common forces: weight (mg), normal, tension, friction (μN), and drag.'),
      ],
      'energy': [
        t('Physics • Energy'),
        t('Conservation of energy: total energy remains constant in a closed system.'),
        t('Kinetic: 1/2 mv^2; Potential (gravity near Earth): mgh; Work: W = F·d.'),
      ],
      'waves': [
        t('Physics • Waves'),
        t('Characterized by wavelength λ, frequency f, amplitude A, and speed v = fλ.'),
        t('Types: mechanical (sound) and electromagnetic (light).'),
      ],
      'electricity': [
        t('Physics • Electricity'),
        t('Ohm’s Law: V = IR; Power: P = VI. Series vs parallel circuits affect total R and current paths.'),
      ],
      // Chemistry
      'atoms': [
        t('Chemistry • Atoms'),
        t('Atoms consist of protons (+), neutrons (0), and electrons (-). Atomic number = protons.'),
      ],
      'molecules': [
        t('Chemistry • Molecules'),
        t('Molecules are groups of atoms bonded together. Covalent (shared electrons) vs ionic (transferred electrons).'),
      ],
      'reactions': [
        t('Chemistry • Reactions'),
        t('Chemical reactions rearrange atoms: reactants → products. Balance equations to conserve mass.'),
      ],
      'acids-bases': [
        t('Chemistry • Acids & Bases'),
        t('Acids donate H+; bases accept H+ (Brønsted–Lowry). pH < 7 acidic, pH = 7 neutral, pH > 7 basic.'),
      ],
      // Biology
      'cells': [
        t('Biology • Cells'),
        t('Cells are the basic units of life. Prokaryotes lack a nucleus; eukaryotes have membrane-bound organelles.'),
      ],
      'genetics': [
        t('Biology • Genetics'),
        t('Genes encode traits. Alleles can be dominant or recessive; Mendelian patterns include monohybrid and dihybrid crosses.'),
      ],
      'evolution': [
        t('Biology • Evolution'),
        t('Evolution occurs via natural selection, mutation, gene flow, and genetic drift.'),
      ],
      'ecosystems': [
        t('Biology • Ecosystems'),
        t('Communities of organisms interacting with their environment; energy flows and matter cycles through trophic levels.'),
      ],
      'anatomy': [
        t('Biology • Anatomy'),
        t('Study of body structures: major systems include circulatory, respiratory, nervous, digestive, and musculoskeletal.'),
      ],
    },
    history: {
      // Ancient
      'mesopotamia': [
        t('Ancient • Mesopotamia'),
        t('Cradle of Civilization between Tigris and Euphrates. Inventions include writing (cuneiform) and the wheel.'),
      ],
      'ancient-egypt': [
        t('Ancient • Egypt'),
        t('Centered along the Nile; pharaohs, pyramids, hieroglyphics, and advanced engineering and agriculture.'),
      ],
      'ancient-greece': [
        t('Ancient • Greece'),
        t('City-states (Athens, Sparta), birth of democracy, philosophy, theater, and the Olympics.'),
      ],
      'ancient-rome': [
        t('Ancient • Rome'),
        t('Republic to Empire, Roman law, roads, aqueducts, and Latin language legacy.'),
      ],
      // Middle Ages
      'feudalism': [
        t('Middle Ages • Feudalism'),
        t('A hierarchical system of lords, vassals, and serfs; land exchanged for military service and labor.'),
      ],
      'crusades': [
        t('Middle Ages • Crusades'),
        t('Series of religious wars between Christians and Muslims, reshaping trade and cultural exchange.'),
      ],
      'cultural-exchange': [
        t('Middle Ages • Cultural Exchange'),
        t('Silk Road trade and knowledge transfer in science, mathematics, and medicine across regions.'),
      ],
      // Modern
      'revolutions': [
        t('Modern • Revolutions'),
        t('Political and social upheavals: American, French, Latin American revolutions reshape governance and rights.'),
      ],
      'world-wars': [
        t('Modern • World Wars'),
        t('Global conflicts (1914–1918; 1939–1945) with profound political, technological, and human impacts.'),
      ],
      'globalization': [
        t('Modern • Globalization'),
        t('Increasing interconnection through trade, technology, culture, and migration; impacts economies and identities.'),
      ],
      'technology': [
        t('Modern • Technology'),
        t('Industrial to Digital Revolutions: mechanization, electricity, computing, and the internet transform life.'),
      ],
    },
  };

  const blocks = content[course][normalizeTopicKey(topicRaw) || ''] || [
    t(`Notes for ${topicRaw}`),
    t('Start adding your notes here.'),
  ];

  return {
    id: '',
    course,
    topic: normalizeTopicKey(topicRaw) || topicRaw,
    blocks,
    updated_at: new Date().toISOString(),
  };
}

export function useNotes() {
  const [loading, setLoading] = useState(false);
  const [note, setNote] = useState<Note | null>(null);
  const [syncingMessage, setSyncingMessage] = useState<string>('');
  const [supabaseConfigured, setSupabaseConfigured] = useState<boolean>(false);

  useEffect(() => {
    // Check Supabase availability (no admin permissions required)
    (async () => {
      const ok = await isSupabaseAvailable();
      setSupabaseConfigured(ok);
    })();
  }, []);

  const saveLocal = async (course: CourseId, n: Note, topic?: string | null) => {
    const tkey = normalizeTopicKey(topic);
    const key = tkey ? `${STORAGE_PREFIX}${course}:${tkey}` : `${STORAGE_PREFIX}${course}`;
    await AsyncStorage.setItem(key, JSON.stringify(n));
  };

  const loadLocal = async (course: CourseId, topic?: string | null): Promise<Note | null> => {
    const tkey = normalizeTopicKey(topic);
    const key = tkey ? `${STORAGE_PREFIX}${course}:${tkey}` : `${STORAGE_PREFIX}${course}`;
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      console.log('Failed to parse local note', e);
      return null;
    }
  };

  const loadNoteForCourse = useCallback(async (course: CourseId, topic?: string | null) => {
    setLoading(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id || null;
      const tkey = normalizeTopicKey(topic);

      if (supabaseConfigured && userId) {
        if (tkey) {
          // per-topic load
          const { data, error } = await supabase
            .from('user_topic_notes')
            .select('*')
            .eq('user_id', userId)
            .eq('course', course as any)
            .eq('topic', tkey)
            .maybeSingle();

          if (error) {
            console.log('loadNote topic remote error, falling back to local/default', error.message);
            const local = await loadLocal(course, tkey);
            const n = local || defaultNoteForTopic(course, tkey);
            setNote(n);
            if (!local) await saveLocal(course, n, tkey);
          } else if (data) {
            const n: Note = {
              id: (data as any).id,
              course: (data as any).course || course,
              topic: (data as any).topic,
              blocks: (data as any).blocks || [],
              updated_at: (data as any).updated_at || new Date().toISOString(),
            };
            setNote(n);
            await saveLocal(course, n, tkey);
          } else {
            const def = defaultNoteForTopic(course, tkey);
            setNote(def);
            await saveLocal(course, def, tkey);
          }
        } else {
          // course-level load
          const { data, error } = await supabase
            .from('user_course_notes')
            .select('*')
            .eq('user_id', userId)
            .eq('course', course as any)
            .maybeSingle();

          if (error) {
            console.log('loadNote remote error, falling back to local/default', error.message);
            const local = await loadLocal(course);
            const n = local || defaultNoteFor(course);
            setNote(n);
            if (!local) await saveLocal(course, n);
          } else if (data) {
            const n: Note = {
              id: (data as any).id,
              course: (data as any).course || course,
              blocks: (data as any).blocks || [],
              updated_at: (data as any).updated_at || new Date().toISOString(),
            };
            setNote(n);
            await saveLocal(course, n);
          } else {
            const def = defaultNoteFor(course);
            setNote(def);
            await saveLocal(course, def);
          }
        }
      } else {
        const local = await loadLocal(course, tkey || undefined);
        const n = local || (tkey ? defaultNoteForTopic(course, tkey) : defaultNoteFor(course));
        setNote(n);
        if (!local) await saveLocal(course, n, tkey || undefined);
      }
    } finally {
      setLoading(false);
    }
  }, [supabaseConfigured]);

  const upsertNoteRemote = async (course: CourseId, blocks: ContentBlock[], topic?: string | null) => {
    setSyncingMessage('Syncing with Supabase...');
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id;
      if (!userId) {
        setSyncingMessage('Not logged in. Saved locally.');
        return null;
      }
      const tkey = normalizeTopicKey(topic);
      if (tkey) {
        const { data, error } = await supabase
          .from('user_topic_notes')
          .upsert(
            [{ user_id: userId, course, topic: tkey, blocks } as any],
            { onConflict: 'user_id,course,topic' as any }
          )
          .select('*')
          .maybeSingle();

        if (error) {
          console.log('upsert topic note error', error.message);
          setSyncingMessage('Sync failed, saved locally');
          return null;
        }

        setSyncingMessage('Synced');
        return data;
      } else {
        const { data, error } = await supabase
          .from('user_course_notes')
          .upsert(
            [{ user_id: userId, course, blocks } as any],
            { onConflict: 'user_id,course' as any }
          )
          .select('*')
          .maybeSingle();

        if (error) {
          console.log('upsert note error', error.message);
          setSyncingMessage('Sync failed, saved locally');
          return null;
        }

        setSyncingMessage('Synced');
        return data;
      }
    } finally {
      setTimeout(() => setSyncingMessage(''), 1200);
    }
  };

  const appendTextBlock = async (course: CourseId, text: string, topic?: string | null) => {
    const blocks = [...(note?.blocks || []), { type: 'text', text } as ContentBlock];
    const updated: Note = {
      id: note?.id || '',
      course,
      topic: normalizeTopicKey(topic) || undefined,
      blocks,
      updated_at: new Date().toISOString(),
    };
    setNote(updated);
    await saveLocal(course, updated, topic);
    if (supabaseConfigured) {
      const data = await upsertNoteRemote(course, blocks, topic);
      if (data) {
        const synced: Note = {
          id: (data as any).id,
          course: (data as any).course,
          topic: (data as any).topic,
          blocks: (data as any).blocks || [],
          updated_at: (data as any).updated_at,
        };
        setNote(synced);
        await saveLocal(course, synced, topic);
      }
    }
  };

  const uploadToStorage = async (file: { uri: string; name: string; type?: string }) => {
    const path = `${Date.now()}-${file.name}`.replace(/\s+/g, '_');
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) {
        console.log('Upload blocked: not authenticated');
        return null;
      }
      const blob = await fetchBlob(file.uri);
      const { error } = await supabase.storage.from('attachments').upload(path, blob as any, {
        contentType: file.type || 'application/octet-stream',
        upsert: false,
      });
      if (error) {
        console.log('upload error', error.message);
        return null;
      }
      const { data: pub } = supabase.storage.from('attachments').getPublicUrl(path);
      return pub?.publicUrl || null;
    } catch (e) {
      console.log('upload exception', e);
      return null;
    }
  };

  const appendImageBlock = async (course: CourseId, asset: { uri: string; fileName?: string }, topic?: string | null) => {
    let url: string | null = null;
    if (supabaseConfigured) {
      url = await uploadToStorage({
        uri: asset.uri,
        name: asset.fileName || `image-${Date.now()}.jpg`,
        type: 'image/jpeg',
      });
    }
    const blocks = [...(note?.blocks || []), { type: 'image', url: url || asset.uri, name: asset.fileName } as ContentBlock];
    const updated: Note = {
      id: note?.id || '',
      course,
      topic: normalizeTopicKey(topic) || undefined,
      blocks,
      updated_at: new Date().toISOString(),
    };
    setNote(updated);
    await saveLocal(course, updated, topic);
    if (supabaseConfigured) {
      const data = await upsertNoteRemote(course, blocks, topic);
      if (data) {
        const synced: Note = {
          id: (data as any).id,
          course: (data as any).course,
          topic: (data as any).topic,
          blocks: (data as any).blocks || [],
          updated_at: (data as any).updated_at,
        };
        setNote(synced);
        await saveLocal(course, synced, topic);
      }
    }
  };

  const appendFileBlock = async (course: CourseId, doc: { uri: string; name: string; mimeType?: string }, topic?: string | null) => {
    const src = (doc as any).assets?.[0] || (doc as any);
    let url: string | null = null;
    if (supabaseConfigured) {
      url = await uploadToStorage({
        uri: src.uri,
        name: src.name || `file-${Date.now()}.bin`,
        type: src.mimeType || 'application/octet-stream',
      });
    }
    const name = src.name || 'file';
    const localUri = src.uri;
    const blocks = [...(note?.blocks || []), { type: 'file', url: url || localUri, name } as ContentBlock];
    const updated: Note = {
      id: note?.id || '',
      course,
      topic: normalizeTopicKey(topic) || undefined,
      blocks,
      updated_at: new Date().toISOString(),
    };
    setNote(updated);
    await saveLocal(course, updated, topic);
    if (supabaseConfigured) {
      const data = await upsertNoteRemote(course, blocks, topic);
      if (data) {
        const synced: Note = {
          id: (data as any).id,
          course: (data as any).course,
          topic: (data as any).topic,
          blocks: (data as any).blocks || [],
          updated_at: (data as any).updated_at,
        };
        setNote(synced);
        await saveLocal(course, synced, topic);
      }
    }
  };

  return {
    loading,
    note,
    loadNoteForCourse,
    appendTextBlock,
    appendImageBlock,
    appendFileBlock,
    syncingMessage,
    supabaseConfigured,
  };
}

export { normalizeTopicKey, defaultNoteForTopic, defaultNoteFor };
