
import { Text, View, Image, ScrollView, TouchableOpacity, ImageBackground } from 'react-native';
import { Link, router } from 'expo-router';
import { useEffect } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import CourseCard from '../components/CourseCard';
import { courses } from '../types/course';
import { useAuth } from '../hooks/useAuth';
import { LinearGradient } from 'expo-linear-gradient';

const HERO_IMAGE =
  'https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&amp;fit=crop&amp;w=1600&amp;q=80';

export default function MainScreen() {
  const { userId, loading, signOut } = useAuth();

  useEffect(() => {
    console.log('MainScreen mounted');
  }, []);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.backgroundAlt }}>
      <View style={{ width: '100%', marginBottom: 16 }}>
        <ImageBackground
          source={{ uri: HERO_IMAGE }}
          style={{ width: '100%', height: 260, backgroundColor: '#000' }}
          resizeMode="cover"
          imageStyle={{ opacity: 0.95 }}
        >
          <LinearGradient
            colors={['rgba(0,0,0,0.15)', 'rgba(0,0,0,0.65)']}
            style={{ flex: 1, padding: 20, justifyContent: 'flex-end' }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <Image
                source={require('../assets/images/final_quest_240x240.png')}
                style={{ width: 54, height: 54 }}
                resizeMode="contain"
              />
              <View style={{ marginLeft: 10 }}>
                <Text
                  style={[
                    commonStyles.title,
                    { marginTop: 0, marginBottom: 2, textAlign: 'left', color: '#FFF' },
                  ]}
                >
                  SmartStudy
                </Text>
                <Text
                  style={[
                    commonStyles.text,
                    { color: '#E6EAEE', marginBottom: 0, textAlign: 'left' },
                  ]}
                >
                  Courses, Notes, and Quizzes
                </Text>
              </View>

              <View style={{ display: 'contents' }}>
                {userId ? (
                  <TouchableOpacity
                    onPress={signOut}
                    style={{
                      marginLeft: 'auto',
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderRadius: 8,
                      backgroundColor: '#FFFFFF',
                      boxShadow: '0px 1px 2px rgba(0,0,0,0.15)',
                    }}
                  >
                    <Text style={{ color: '#000000', fontWeight: '700' }}>Logout</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => router.push('/auth')}
                    style={{
                      marginLeft: 'auto',
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderRadius: 8,
                      backgroundColor: '#FFFFFF',
                      boxShadow: '0px 1px 2px rgba(0,0,0,0.15)',
                    }}
                  >
                    <Text style={{ color: '#000000', fontWeight: '700' }}>Login / Sign up</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            <Text
              style={{
                color: '#F1F5F9',
                fontSize: 14,
                marginBottom: 6,
              }}
            >
              Your study companion. Organize notes, attach files, and challenge yourself anytime.
            </Text>
          </LinearGradient>
        </ImageBackground>
      </View>

      <View style={[commonStyles.content, { padding: 20, alignItems: 'stretch' }]}>
        <View style={{ flexDirection: 'row', gap: 10, marginBottom: 8 }}>
          <TouchableOpacity
            onPress={() => router.push('/chat')}
            style={{
              flex: 1,
              backgroundColor: colors.card,
              padding: 14,
              borderRadius: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              alignItems: 'center',
            }}
          >
            <Text style={[commonStyles.text, { marginBottom: 0 }]}>Open AI Chat</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push('/daily')}
            style={{
              flex: 1,
              backgroundColor: colors.card,
              padding: 14,
              borderRadius: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              alignItems: 'center',
            }}
          >
            <Text style={[commonStyles.text, { marginBottom: 0 }]}>Daily Challenge</Text>
          </TouchableOpacity>
        </View>

        <View style={{ flexDirection: 'row', gap: 10, marginBottom: 8 }}>
          <TouchableOpacity
            onPress={() => router.push('/progress')}
            style={{
              flex: 1,
              backgroundColor: colors.card,
              padding: 14,
              borderRadius: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              alignItems: 'center',
            }}
          >
            <Text style={[commonStyles.text, { marginBottom: 0 }]}>Progress</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push('/settings')}
            style={{
              flex: 1,
              backgroundColor: colors.card,
              padding: 14,
              borderRadius: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              alignItems: 'center',
            }}
          >
            <Text style={[commonStyles.text, { marginBottom: 0 }]}>Settings</Text>
          </TouchableOpacity>
        </View>

        <View style={{ flexDirection: 'row', gap: 10, marginBottom: 12 }}>
          <TouchableOpacity
            onPress={() => router.push('/connect-github')}
            style={{
              flex: 1,
              backgroundColor: colors.card,
              padding: 14,
              borderRadius: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              alignItems: 'center',
            }}
          >
            <Text style={[commonStyles.text, { marginBottom: 0 }]}>Connect GitHub</Text>
          </TouchableOpacity>
        </View>

        {courses.map((c) => (
          <CourseCard
            key={c.id}
            title={c.name}
            subtitle="Study notes and take a quick quiz"
            onOpenNotes={() => router.push(`/course/${encodeURIComponent(c.id)}/notes`)}
            onOpenQuiz={() => router.push(`/course/${encodeURIComponent(c.id)}/quiz`)}
            iconName={c.icon}
          />
        ))}

        <View style={{ height: 20 }} />
        <Link href="https://supabase.com" style={{ alignSelf: 'center' }}>
          <Text style={[commonStyles.text, { fontSize: 12, color: colors.grey }]}>
            Powered by Supabase (enable in Natively)
          </Text>
        </Link>
      </View>
    </ScrollView>
  );
}
