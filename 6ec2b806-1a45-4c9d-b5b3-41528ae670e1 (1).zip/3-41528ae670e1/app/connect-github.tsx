
import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { signInWithGitHub } from './integrations/supabase/oauth';

export default function ConnectGitHubScreen() {
  const [status, setStatus] = useState<'idle' | 'working' | 'done' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    let mounted = true;
    async function run() {
      setStatus('working');
      try {
        const session = await signInWithGitHub();
        if (!mounted) return;
        if (session) {
          setStatus('done');
          setTimeout(() => router.back(), 600);
        } else {
          // On web, redirect flow happens; we won’t have a session synchronously.
          setStatus('working');
        }
      } catch (e: any) {
        console.log('ConnectGitHub error', e);
        setErrorMessage(e?.message || 'GitHub sign-in failed.');
        setStatus('error');
      }
    }
    run();

    return () => {
      mounted = false;
    };
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.backgroundAlt,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Icon name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>Connect GitHub</Text>
      </View>

      <View style={[commonStyles.container, { paddingHorizontal: 16 }]}>
        {status === 'working' ? (
          <>
            <ActivityIndicator color={colors.primary} />
            <Text style={[commonStyles.text, { marginTop: 10 }]}>
              Opening GitHub… If nothing happens, go back and try again.
            </Text>
          </>
        ) : null}

        {status === 'done' ? (
          <Text style={[commonStyles.text]}>GitHub connected! Returning…</Text>
        ) : null}

        {status === 'error' ? (
          <>
            <Text style={[commonStyles.text, { color: colors.text }]}>{errorMessage}</Text>
            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                marginTop: 12,
                paddingHorizontal: 16,
                paddingVertical: 10,
                borderRadius: 8,
                backgroundColor: colors.backgroundAlt,
                boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
              }}
            >
              <Text style={{ color: colors.text, fontWeight: '700' }}>Back</Text>
            </TouchableOpacity>
          </>
        ) : null}
      </View>
    </View>
  );
}
