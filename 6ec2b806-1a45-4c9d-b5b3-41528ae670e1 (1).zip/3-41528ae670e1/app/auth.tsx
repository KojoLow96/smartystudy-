
import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { supabase } from './integrations/supabase/client';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { signInWithGitHub } from './integrations/supabase/oauth';

export default function AuthScreen() {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function onSubmit() {
    if (busy) return;
    const e = email.trim();
    const p = password.trim();
    if (!e || !p) {
      Alert.alert('Missing fields', 'Please enter both email and password.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: e,
          password: p,
          options: {
            emailRedirectTo: 'https://natively.dev/email-confirmed'
          }
        } as any);
        if (error) {
          Alert.alert('Sign up failed', error.message || 'Please try again.');
        } else {
          Alert.alert(
            'Verify your email',
            'Account created! Please check your inbox and verify your email before logging in.'
          );
          setMode('login');
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: e,
          password: p,
        });
        if (error) {
          // Always display the response message to the user
          Alert.alert('Login failed', error.message || 'Please try again.');
        } else if (data?.session) {
          Alert.alert('Success', 'Logged in successfully!');
          router.back();
        } else {
          Alert.alert('Login', 'Please check your email for a confirmation message and try again.');
        }
      }
    } catch (err: any) {
      console.log('auth submit error', err);
      Alert.alert('Error', err?.message || 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function onGitHub() {
    if (busy) return;
    setBusy(true);
    try {
      const session = await signInWithGitHub();
      if (session) {
        Alert.alert('Success', 'Signed in with GitHub!');
        router.back();
      } else {
        // On web, redirect flow takes over; do nothing here.
        console.log('GitHub web redirect initiated');
      }
    } catch (e: any) {
      console.log('GitHub sign-in error', e);
      Alert.alert('GitHub Sign-in Failed', e?.message || 'Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.backgroundAlt,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Icon name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>{mode === 'login' ? 'Log in' : 'Sign up'}</Text>
      </View>

      <ScrollView style={{ flex: 1, padding: 16 }}>
        <View style={{ backgroundColor: colors.card, padding: 16, borderRadius: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
          <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 6 }]}>Email</Text>
          <TextInput
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@example.com"
            placeholderTextColor="#999"
            value={email}
            onChangeText={setEmail}
            style={{
              backgroundColor: colors.backgroundAlt,
              color: colors.text,
              borderRadius: 10,
              paddingHorizontal: 12,
              paddingVertical: 10,
              marginBottom: 12,
            }}
          />

          <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 6 }]}>Password</Text>
          <TextInput
            secureTextEntry
            placeholder="Your password"
            placeholderTextColor="#999"
            value={password}
            onChangeText={setPassword}
            style={{
              backgroundColor: colors.backgroundAlt,
              color: colors.text,
              borderRadius: 10,
              paddingHorizontal: 12,
              paddingVertical: 10,
            }}
          />

          <TouchableOpacity
            onPress={onSubmit}
            disabled={busy}
            style={{
              padding: 12,
              borderRadius: 10,
              backgroundColor: colors.primary,
              alignItems: 'center',
              marginTop: 16,
              boxShadow: '0px 2px 6px rgba(0,0,0,0.08)',
              opacity: busy ? 0.7 : 1,
            }}
          >
            <Text style={{ color: 'white', fontWeight: '700' }}>
              {mode === 'login' ? 'Log in' : 'Create account'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setMode(mode === 'login' ? 'signup' : 'login')}
            style={{ padding: 12, borderRadius: 10, alignItems: 'center', marginTop: 10 }}
          >
            <Text style={[commonStyles.text, { color: colors.secondary, marginBottom: 0 }]}>
              {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Log in'}
            </Text>
          </TouchableOpacity>

          <View style={{ height: 12 }} />

          <View style={{ height: 1, backgroundColor: '#E3E8EF', marginVertical: 8 }} />

          <TouchableOpacity
            onPress={onGitHub}
            disabled={busy}
            style={{
              padding: 12,
              borderRadius: 10,
              backgroundColor: colors.backgroundAlt,
              alignItems: 'center',
              marginTop: 8,
              boxShadow: '0px 2px 6px rgba(0,0,0,0.06)',
              flexDirection: 'row',
              justifyContent: 'center',
              opacity: busy ? 0.7 : 1,
            }}
          >
            <Icon name="logo-github" size={18} color={colors.text} />
            <Text style={{ color: colors.text, fontWeight: '700', marginLeft: 8 }}>
              Continue with GitHub
            </Text>
          </TouchableOpacity>

          <View style={{ height: 10 }} />
          <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey, fontSize: 12 }]}>
            After signing up, you must verify your email via the link sent to your inbox before you can log in.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
