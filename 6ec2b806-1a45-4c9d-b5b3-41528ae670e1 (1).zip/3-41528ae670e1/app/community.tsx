
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { router } from 'expo-router';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { useAuth } from '../hooks/useAuth';
import { supabase } from './integrations/supabase/client';
import { courses, CourseId } from '../types/course';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView } from '@gorhom/bottom-sheet';

type Post = {
  id: string;
  user_id: string;
  course: CourseId;
  content: string;
  like_count?: number;
  comment_count?: number;
  created_at: string;
};

type Comment = {
  id: string;
  user_id: string;
  post_id: string;
  content: string;
  created_at: string;
};

export default function CommunityScreen() {
  const { userId } = useAuth();
  const [supabaseConfigured, setSupabaseConfigured] = useState(true);
  const [posts, setPosts] = useState<Post[]>([]);
  const [draft, setDraft] = useState('');
  const [course, setCourse] = useState<CourseId>('mathematics');
  const [loading, setLoading] = useState(false);
  const [likedPostIds, setLikedPostIds] = useState<Set<string>>(new Set());

  const [activePost, setActivePost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentDraft, setCommentDraft] = useState('');

  const sheetRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ['50%'], []);

  useEffect(() => {
    (async () => {
      try {
        const { error } = await supabase.storage.listBuckets();
        if (error) {
          setSupabaseConfigured(false);
        } else {
          setSupabaseConfigured(true);
        }
      } catch {
        setSupabaseConfigured(false);
      }
    })();
  }, []);

  const loadLiked = useCallback(async () => {
    if (!supabaseConfigured || !userId) {
      setLikedPostIds(new Set());
      return;
    }
    try {
      const { data, error } = await supabase
        .from('study_likes')
        .select('post_id')
        .eq('user_id', userId);
      if (!error && data) {
        setLikedPostIds(new Set((data as any[]).map((d: any) => d.post_id)));
      }
    } catch (e) {
      console.log('loadLiked error', e);
    }
  }, [supabaseConfigured, userId]);

  const loadPosts = useCallback(async () => {
    setLoading(true);
    try {
      if (!supabaseConfigured) {
        setPosts([
          {
            id: 'demo-1',
            user_id: 'demo_user',
            course: 'mathematics',
            content: 'Anyone has tips for Integrals? What helped you understand them?',
            like_count: 2,
            comment_count: 1,
            created_at: new Date().toISOString(),
          },
          {
            id: 'demo-2',
            user_id: 'demo_user',
            course: 'history',
            content: 'Share a good video about the Renaissance origins!',
            like_count: 1,
            comment_count: 0,
            created_at: new Date().toISOString(),
          },
        ]);
        return;
      }
      const { data, error } = await supabase
        .from('study_posts')
        .select('*')
        .order('created_at', { ascending: false } as any)
        .limit(50);
      if (error) {
        console.log('loadPosts error', error.message);
        setPosts([]);
      } else {
        setPosts((data || []) as any);
      }
    } finally {
      setLoading(false);
    }
  }, [supabaseConfigured]);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  useEffect(() => {
    loadLiked();
  }, [loadLiked]);

  const submit = useCallback(async () => {
    const text = draft.trim();
    if (!text) return;
    if (!userId) {
      Alert.alert('Login required', 'Please log in to post.');
      return;
    }
    if (!supabaseConfigured) {
      Alert.alert('Supabase disabled', 'Enable Supabase in Natively to publish posts.');
      return;
    }
    try {
      const { error } = await supabase
        .from('study_posts')
        .insert([{ user_id: userId, content: text, course } as any]);
      if (error) {
        Alert.alert('Post failed', error.message || 'Please try again.');
      } else {
        setDraft('');
        loadPosts();
      }
    } catch (e: any) {
      Alert.alert('Post failed', e?.message || 'Please try again.');
    }
  }, [draft, userId, supabaseConfigured, course, loadPosts]);

  const toggleLike = useCallback(async (p: Post) => {
    if (!userId) {
      Alert.alert('Login required', 'Please log in to like posts.');
      return;
    }
    if (!supabaseConfigured) {
      // local like toggle
      const has = likedPostIds.has(p.id);
      const nextSet = new Set(likedPostIds);
      if (has) nextSet.delete(p.id); else nextSet.add(p.id);
      setLikedPostIds(nextSet);
      setPosts(prev => prev.map(x => x.id === p.id ? { ...x, like_count: Math.max(0, (x.like_count || 0) + (has ? -1 : 1)) } : x));
      return;
    }
    try {
      const has = likedPostIds.has(p.id);
      if (has) {
        const { error } = await supabase.from('study_likes').delete().eq('post_id', p.id).eq('user_id', userId);
        if (!error) {
          setLikedPostIds(s => {
            const copy = new Set(s);
            copy.delete(p.id);
            return copy;
          });
          setPosts(prev => prev.map(x => x.id === p.id ? { ...x, like_count: Math.max(0, (x.like_count || 0) - 1) } : x));
        }
      } else {
        const { error } = await supabase.from('study_likes').insert([{ post_id: p.id, user_id: userId } as any]);
        if (!error) {
          setLikedPostIds(s => new Set([...Array.from(s), p.id]));
          setPosts(prev => prev.map(x => x.id === p.id ? { ...x, like_count: (x.like_count || 0) + 1 } : x));
        }
      }
    } catch (e) {
      console.log('toggleLike error', e);
    }
  }, [likedPostIds, userId, supabaseConfigured]);

  const openComments = useCallback(async (p: Post) => {
    setActivePost(p);
    setCommentDraft('');
    if (!supabaseConfigured) {
      setComments([]);
      sheetRef.current?.expand();
      return;
    }
    try {
      const { data, error } = await supabase
        .from('study_comments')
        .select('*')
        .eq('post_id', p.id)
        .order('created_at', { ascending: true } as any);
      if (error) {
        console.log('load comments error', error.message);
        setComments([]);
      } else {
        setComments((data || []) as any);
      }
      sheetRef.current?.expand();
    } catch (e) {
      console.log('openComments exception', e);
      setComments([]);
      sheetRef.current?.expand();
    }
  }, [supabaseConfigured]);

  const addComment = useCallback(async () => {
    const text = commentDraft.trim();
    if (!text) return;
    if (!userId) {
      Alert.alert('Login required', 'Please log in to comment.');
      return;
    }
    if (!activePost) return;
    if (!supabaseConfigured) {
      const fake: Comment = {
        id: `local-${Date.now()}`,
        user_id: userId,
        post_id: activePost.id,
        content: text,
        created_at: new Date().toISOString(),
      };
      setComments(prev => [...prev, fake]);
      setCommentDraft('');
      setPosts(prev => prev.map(x => x.id === activePost.id ? { ...x, comment_count: (x.comment_count || 0) + 1 } : x));
      return;
    }
    try {
      const { data, error } = await supabase
        .from('study_comments')
        .insert([{ user_id: userId, post_id: activePost.id, content: text } as any])
        .select('*')
        .maybeSingle();
      if (error) {
        Alert.alert('Comment failed', error.message || 'Please try again.');
      } else if (data) {
        setComments(prev => [...prev, data as any]);
        setCommentDraft('');
        setPosts(prev => prev.map(x => x.id === activePost.id ? { ...x, comment_count: (x.comment_count || 0) + 1 } : x));
      }
    } catch (e) {
      console.log('addComment exception', e);
    }
  }, [commentDraft, userId, activePost, supabaseConfigured]);

  return (
    <>
      <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={{ padding: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 8,
                backgroundColor: colors.backgroundAlt,
                boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
              }}
            >
              <Icon name="chevron-back" size={22} color={colors.text} />
            </TouchableOpacity>
            <Text style={[commonStyles.title, { marginLeft: 12, flex: 1, textAlign: 'left' }]}>
              Community
            </Text>
          </View>

          <View style={{ backgroundColor: colors.card, padding: 14, borderRadius: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
            <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 6 }]}>Share a study note or ask a question</Text>
            <View style={{ flexDirection: 'row', marginBottom: 8 }}>
              {courses.map(c => (
                <TouchableOpacity
                  key={c.id}
                  onPress={() => setCourse(c.id)}
                  style={{
                    paddingHorizontal: 12,
                    paddingVertical: 8,
                    borderRadius: 999,
                    backgroundColor: course === c.id ? colors.primary : colors.backgroundAlt,
                    marginRight: 8,
                    boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                  }}
                >
                  <Text style={{ color: course === c.id ? '#fff' : colors.text, fontWeight: '700', fontSize: 12 }}>{c.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput
              placeholder="Write something helpful..."
              placeholderTextColor="#999"
              value={draft}
              onChangeText={setDraft}
              multiline
              style={{
                backgroundColor: colors.backgroundAlt,
                color: colors.text,
                borderRadius: 10,
                paddingHorizontal: 12,
                paddingVertical: 10,
                minHeight: 70,
              }}
            />
            <TouchableOpacity
              onPress={submit}
              style={{
                padding: 12,
                borderRadius: 10,
                backgroundColor: colors.primary,
                alignItems: 'center',
                marginTop: 10,
                boxShadow: '0px 2px 6px rgba(0,0,0,0.08)',
              }}
            >
              <Text style={{ color: 'white', fontWeight: '700' }}>Post</Text>
            </TouchableOpacity>
            {!supabaseConfigured ? (
              <Text style={{ marginTop: 8, color: '#6D4C41', fontSize: 12 }}>
                Enable Supabase to publish posts globally. Demo posts are shown below.
              </Text>
            ) : null}
          </View>

          <View style={{ height: 10 }} />

          {posts.map(p => {
            const liked = likedPostIds.has(p.id);
            return (
              <View key={p.id} style={{ backgroundColor: colors.card, borderRadius: 12, padding: 14, marginBottom: 10, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
                <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 2 }]}>
                  [{p.course.toUpperCase()}]
                </Text>
                <Text style={[commonStyles.text, { textAlign: 'left' }]}>{p.content}</Text>
                <Text style={{ fontSize: 11, color: colors.grey, marginTop: 6 }}>By User {p.user_id?.slice(0, 6)}…</Text>

                <View style={{ flexDirection: 'row', marginTop: 8 }}>
                  <TouchableOpacity
                    onPress={() => toggleLike(p)}
                    style={{
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderRadius: 8,
                      backgroundColor: liked ? colors.primary : colors.backgroundAlt,
                      boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                      marginRight: 8,
                    }}
                  >
                    <Text style={{ color: liked ? '#fff' : colors.text, fontWeight: '700' }}>
                      {liked ? 'Liked' : 'Like'} {typeof p.like_count === 'number' ? `(${p.like_count})` : ''}
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => openComments(p)}
                    style={{
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderRadius: 8,
                      backgroundColor: colors.backgroundAlt,
                      boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                    }}
                  >
                    <Text style={{ color: colors.text, fontWeight: '700' }}>
                      Comments {typeof p.comment_count === 'number' ? `(${p.comment_count})` : ''}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            );
          })}

          {loading ? (
            <Text style={[commonStyles.text, { textAlign: 'center', color: colors.grey }]}>Loading…</Text>
          ) : null}
        </View>
      </ScrollView>

      <BottomSheet
        ref={sheetRef}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backdropComponent={(props) => <BottomSheetBackdrop {...props} appearsOnIndex={0} disappearsOnIndex={-1} />}
      >
        <BottomSheetView style={{ flex: 1, backgroundColor: colors.background, padding: 12 }}>
          <Text style={[commonStyles.title, { textAlign: 'left' }]}>Comments</Text>
          {activePost ? (
            <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>
              [{activePost.course.toUpperCase()}] {activePost.content}
            </Text>
          ) : null}

          <ScrollView style={{ flex: 1, marginTop: 8 }}>
            {comments.length === 0 ? (
              <Text style={[commonStyles.text, { textAlign: 'center', color: colors.grey }]}>No comments yet.</Text>
            ) : (
              comments.map(c => (
                <View key={c.id} style={{ backgroundColor: colors.card, padding: 10, borderRadius: 10, marginBottom: 8, boxShadow: '0px 2px 6px rgba(0,0,0,0.06)' }}>
                  <Text style={[commonStyles.text, { textAlign: 'left', fontSize: 13, marginBottom: 2 }]}>
                    {c.content}
                  </Text>
                  <Text style={{ fontSize: 11, color: colors.grey }}>By {c.user_id.slice(0, 6)}…</Text>
                </View>
              ))
            )}
            <View style={{ height: 80 }} />
          </ScrollView>

          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <TextInput
              placeholder="Write a comment…"
              placeholderTextColor="#999"
              value={commentDraft}
              onChangeText={setCommentDraft}
              style={{
                flex: 1,
                backgroundColor: colors.backgroundAlt,
                color: colors.text,
                borderRadius: 10,
                paddingHorizontal: 12,
                paddingVertical: 10,
                boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
              }}
            />
            <TouchableOpacity
              onPress={addComment}
              style={{
                paddingHorizontal: 14,
                paddingVertical: 10,
                borderRadius: 10,
                backgroundColor: colors.primary,
                boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
              }}
            >
              <Text style={{ color: 'white', fontWeight: '700' }}>Send</Text>
            </TouchableOpacity>
          </View>
        </BottomSheetView>
      </BottomSheet>
    </>
  );
}
