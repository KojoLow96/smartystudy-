
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Platform, SafeAreaView } from 'react-native';
import { commonStyles } from '../styles/commonStyles';
import { useEffect } from 'react';
import { setupErrorLogging } from '../utils/errorLogger';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function RootLayout() {
  useEffect(() => {
    setupErrorLogging();
  }, []);

  const insetsToUse = { top: 0, bottom: 0, left: 0, right: 0 };

  return (
    <SafeAreaProvider>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaView
          style={[
            commonStyles.wrapper,
            {
              paddingTop: insetsToUse.top,
              paddingBottom: insetsToUse.bottom,
              paddingLeft: insetsToUse.left,
              paddingRight: insetsToUse.right,
            },
          ]}
        >
          <StatusBar style={Platform.OS === 'ios' ? 'dark' : 'light'} />
          <Stack
            screenOptions={{
              headerShown: false,
              animation: 'default',
            }}
          />
        </SafeAreaView>
      </GestureHandlerRootView>
    </SafeAreaProvider>
  );
}
