
import { useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { courses } from '../types/course';
import ProgressDonut from '../components/ProgressDonut';
import { useAuth } from '../hooks/useAuth';
import { useGamification } from '../hooks/useGamification';

export default function ProgressScreen() {
  const { userId } = useAuth();
  const { sessions } = useGamification(userId || null);

  const perCourse = useMemo(() => {
    return courses.map(c => {
      const ss = sessions.filter(s => s.course === c.id);
      const totalAnswered = ss.reduce((acc, s) => acc + s.total, 0);
      const totalCorrect = ss.reduce((acc, s) => acc + Math.round((s.accuracy || 0) * s.total), 0);
      const acc = totalAnswered > 0 ? totalCorrect / totalAnswered : 0;
      return {
        id: c.id,
        name: c.name,
        icon: c.icon,
        sessions: ss.length,
        accuracy: acc,
        questions: totalAnswered,
      };
    });
  }, [sessions]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.backgroundAlt,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Icon name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>Progress</Text>
      </View>

      <View style={{ padding: 16 }}>
        {perCourse.map((pc) => (
          <View
            key={pc.id}
            style={{
              backgroundColor: colors.card,
              borderRadius: 12,
              padding: 14,
              marginBottom: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <View style={{ marginRight: 12 }}>
              <ProgressDonut size={60} strokeWidth={8} progress={pc.accuracy} />
            </View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 2 }}>
                <Icon name={pc.icon} size={20} color={colors.secondary} />
                <Text style={[commonStyles.title, { marginLeft: 6, textAlign: 'left' }]}>{pc.name}</Text>
              </View>
              <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 0, color: colors.grey }]}>
                Accuracy: {Math.round(pc.accuracy * 100)}% • Answered: {pc.questions}
              </Text>
              <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 0, color: colors.grey }]}>
                Sessions: {pc.sessions}
              </Text>
            </View>
            <View style={{ marginLeft: 12 }}>
              <TouchableOpacity
                onPress={() => router.push(`/course/${encodeURIComponent(pc.id)}/quiz`)}
                style={{
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                  borderRadius: 8,
                  backgroundColor: colors.primary,
                  boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
                }}
              >
                <Text style={{ color: '#fff', fontWeight: '700' }}>Practice</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}
