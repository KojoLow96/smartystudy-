
import { useLocalSearchParams, router } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import Icon from '../../../components/Icon';
import { colors, commonStyles } from '../../../styles/commonStyles';
import { courseById } from '../../../types/course';
import ProgressDonut from '../../../components/ProgressDonut';
import { getQuestionsForCourse, QuizQuestion } from '../../../data/quizzes';
import { useGamification } from '../../../hooks/useGamification';

type AnswerRecord = {
  questionId: string;
  selectedIndex: number | null;
  correctIndex: number;
  correct: boolean;
};

type Mode = 'normal' | 'daily';

function shuffle<T>(arr: T[], seed = 1): T[] {
  let a = arr.slice();
  let random = mulberry32(seed);
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function mulberry32(a: number) {
  return function() {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
}
function todaySeed() {
  const d = new Date();
  return Number(`${d.getFullYear()}${d.getMonth()+1}${d.getDate()}`);
}

export default function CourseQuizScreen() {
  const { course, mode } = useLocalSearchParams<{ course: string; mode?: Mode }>();
  const courseObj = courseById(course || '');
  const allQuestions = useMemo(() => getQuestionsForCourse(courseObj.id), [courseObj.id]);
  const quizMode = (mode as Mode) || 'normal';

  const { startSession, recordAnswer, finishSession } = useGamification(); // use local+remote sync

  const [sessionStarted, setSessionStarted] = useState(false);
  const [pointsEarned, setPointsEarned] = useState<number | null>(null);

  const [askedIds, setAskedIds] = useState<string[]>([]);
  const [current, setCurrent] = useState<QuizQuestion | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [reducedOptions, setReducedOptions] = useState<number[] | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const [lifelines, setLifelines] = useState<{ fifty: boolean; skip: boolean; hint: boolean }>({
    fifty: true,
    skip: true,
    hint: true,
  });

  const QUESTION_SECONDS = 30;
  const [secondsLeft, setSecondsLeft] = useState<number>(QUESTION_SECONDS);
  const timerRef = useRef<any>(null);

  const totalPlanned = useMemo(() => {
    if (quizMode === 'daily') return Math.min(5, allQuestions.length);
    return Math.min(10, allQuestions.length);
  }, [quizMode, allQuestions.length]);

  const accuracy = useMemo(() => {
    const total = answers.length;
    if (total === 0) return 0;
    const correct = answers.filter(a => a.correct).length;
    return correct / total;
  }, [answers]);

  const progress = useMemo(() => {
    if (totalPlanned === 0) return 0;
    return Math.min(answers.length / totalPlanned, 1);
  }, [answers.length, totalPlanned]);

  useEffect(() => {
    const seed = quizMode === 'daily' ? todaySeed() : Date.now();
    const shuffled = shuffle(allQuestions, seed);
    const first = pickNextAdaptive(shuffled, [], 0);
    setCurrent(first);
    setAskedIds(first ? [first.id] : []);
    setSecondsLeft(QUESTION_SECONDS);
    setPointsEarned(null);
    setSessionStarted(false);
  }, [courseObj.id, quizMode]);

  useEffect(() => {
    if (!sessionStarted) {
      setSessionStarted(true);
      startSession(courseObj.id as any, quizMode as any).then(() => {
        // started
      }).catch(e => console.log('startSession err', e));
    }
  }, [sessionStarted, startSession, courseObj.id, quizMode]);

  useEffect(() => {
    if (!current) return;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(timerRef.current);
          if (selected === null) {
            commitAnswer(null);
          } else {
            setShowExplanation(true);
          }
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [current]);

  function pickNextAdaptive(pool: QuizQuestion[], asked: string[], acc: number): QuizQuestion | null {
    const remaining = pool.filter(q => !asked.includes(q.id));
    if (remaining.length === 0) return null;

    let target: 'easy' | 'medium' | 'hard';
    if (acc >= 0.8) target = 'hard';
    else if (acc >= 0.5) target = 'medium';
    else target = 'easy';

    const same = remaining.filter(q => q.difficulty === target);
    if (same.length > 0) return same[0];

    const med = remaining.filter(q => q.difficulty === 'medium');
    if (med.length > 0) return med[0];

    return remaining[0];
  }

  function onSelect(i: number) {
    if (!current) return;
    setSelected(i);
  }

  function commitAnswer(selectedIndex: number | null) {
    if (!current) return;
    const record: AnswerRecord = {
      questionId: current.id,
      selectedIndex,
      correctIndex: current.correctIndex,
      correct: selectedIndex === current.correctIndex,
    };
    setAnswers(prev => [...prev, record]);
    // record in gamification
    recordAnswer({
      questionId: record.questionId,
      selectedIndex: record.selectedIndex,
      correctIndex: record.correctIndex,
      correct: record.correct,
    }).catch(e => console.log('recordAnswer err', e));
    setShowExplanation(true);
  }

  function onConfirm() {
    if (selected === null) return;
    commitAnswer(selected);
  }

  function onNext() {
    if (answers.length >= totalPlanned) {
      return;
    }
    const next = pickNextAdaptive(allQuestions, askedIds, accuracy);
    if (!next || askedIds.length + 1 > totalPlanned) {
      setCurrent(null);
      return;
    }
    setCurrent(next);
    setAskedIds(prev => [...prev, next.id]);
    setSelected(null);
    setShowExplanation(false);
    setReducedOptions(null);
    setSecondsLeft(QUESTION_SECONDS);
  }

  function onRestart() {
    const seed = quizMode === 'daily' ? todaySeed() : Date.now();
    const shuffled = shuffle(allQuestions, seed);
    const first = pickNextAdaptive(shuffled, [], 0);
    setCurrent(first);
    setAskedIds(first ? [first.id] : []);
    setSelected(null);
    setAnswers([]);
    setShowExplanation(false);
    setReducedOptions(null);
    setLifelines({ fifty: true, skip: true, hint: true });
    setSecondsLeft(QUESTION_SECONDS);
    setPointsEarned(null);
    setSessionStarted(false);
  }

  function useFifty() {
    if (!current || !lifelines.fifty) return;
    const wrongs = current.options
      .map((_, idx) => idx)
      .filter((idx) => idx !== current.correctIndex);
    const toRemove = shuffle(wrongs, 2).slice(0, 2);
    const keep = current.options
      .map((_, idx) => idx)
      .filter((idx) => !toRemove.includes(idx));
    setReducedOptions(keep);
    setLifelines(prev => ({ ...prev, fifty: false }));
  }

  function useSkip() {
    if (!current || !lifelines.skip) return;
    commitAnswer(null);
    setLifelines(prev => ({ ...prev, skip: false }));
  }

  const finished = answers.length >= totalPlanned && (current === null || askedIds.length >= totalPlanned);
  const correctCount = answers.filter(a => a.correct).length;
  const totalAnswered = answers.length;
  const accPct = totalAnswered > 0 ? Math.round((correctCount / totalAnswered) * 100) : 0;

  useEffect(() => {
    if (finished && pointsEarned === null) {
      finishSession().then(({ pointsEarned: earned }) => {
        setPointsEarned(earned);
      }).catch(e => console.log('finishSession err', e));
    }
  }, [finished, pointsEarned, finishSession]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.backgroundAlt,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Icon name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>{courseObj.name} {quizMode === 'daily' ? 'Daily' : 'Quiz'}</Text>
        <View style={{ display: 'contents' }}>
          <ProgressDonut size={38} strokeWidth={6} progress={progress} />
        </View>
      </View>

      {finished ? (
        <ScrollView style={{ flex: 1, paddingHorizontal: 16 }}>
          <View style={{ padding: 16, backgroundColor: colors.card, borderRadius: 12, marginTop: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
            <Text style={[commonStyles.title, { marginBottom: 8, textAlign: 'left' }]}>Results</Text>
            <Text style={[commonStyles.text, { textAlign: 'left' }]}>Score: {correctCount} / {totalPlanned}</Text>
            <Text style={[commonStyles.text, { textAlign: 'left' }]}>Accuracy: {accPct}%</Text>
            {pointsEarned !== null ? (
              <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>
                +{pointsEarned} points added to your account
              </Text>
            ) : null}
            <TouchableOpacity
              onPress={onRestart}
              style={{
                marginTop: 12,
                backgroundColor: colors.primary,
                paddingHorizontal: 16,
                paddingVertical: 10,
                borderRadius: 8,
                alignSelf: 'flex-start',
                boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
              }}
            >
              <Text style={{ color: 'white', fontWeight: '700' }}>Restart</Text>
            </TouchableOpacity>
          </View>

          <View style={{ height: 8 }} />

          <View style={{ padding: 16, backgroundColor: colors.card, borderRadius: 12, marginTop: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
            <Text style={[commonStyles.title, { marginBottom: 8, textAlign: 'left' }]}>Review</Text>
            {answers.map((a, i) => {
              const q = allQuestions.find(q => q.id === a.questionId);
              if (!q) return null;
              const wasCorrect = a.correct;
              return (
                <View key={q.id} style={{ marginBottom: 12, padding: 12, borderRadius: 10, backgroundColor: wasCorrect ? '#E8F5E9' : '#FFEBEE' }}>
                  <Text style={[commonStyles.text, { textAlign: 'left', fontWeight: '700' }]}>Q{i + 1}. {q.prompt}</Text>
                  <Text style={[commonStyles.text, { textAlign: 'left' }]}>Your answer: {a.selectedIndex !== null ? q.options[a.selectedIndex] : 'Skipped'}</Text>
                  <Text style={[commonStyles.text, { textAlign: 'left' }]}>Correct answer: {q.options[q.correctIndex]}</Text>
                  <Text style={{ fontSize: 12, color: colors.grey, marginTop: 6, textAlign: 'left' }}>Explanation: {q.explanation}</Text>
                </View>
              );
            })}
          </View>
          <View style={{ height: 40 }} />
        </ScrollView>
      ) : (
        <ScrollView style={{ flex: 1, paddingHorizontal: 16 }}>
          {current ? (
            <View
              style={{
                backgroundColor: colors.card,
                borderRadius: 12,
                padding: 16,
                marginTop: 12,
                boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              }}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8, justifyContent: 'space-between' }}>
                <Text style={[commonStyles.text, { fontSize: 14, color: colors.grey, textAlign: 'left' }]}>
                  Q{answers.length + 1} of {totalPlanned} • Difficulty: {current.difficulty.toUpperCase()}
                </Text>
                <View style={{ backgroundColor: colors.backgroundAlt, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 }}>
                  <Text style={[commonStyles.text, { marginBottom: 0 }]}>⏱ {secondsLeft}s</Text>
                </View>
              </View>

              <Text style={[commonStyles.text, { fontSize: 18, marginBottom: 10, textAlign: 'left' }]}>
                {current.prompt}
              </Text>

              {(reducedOptions ? reducedOptions : current.options.map((_, i) => i)).map((idx) => {
                const isSelected = selected === idx;
                const feedback =
                  showExplanation && selected !== null
                    ? (idx === current.correctIndex ? '✔️' : (isSelected ? '❌' : ''))
                    : '';
                return (
                  <TouchableOpacity
                    key={idx}
                    onPress={() => onSelect(idx)}
                    disabled={showExplanation}
                    style={{
                      padding: 12,
                      borderRadius: 10,
                      marginBottom: 10,
                      borderWidth: 1,
                      borderColor: isSelected ? colors.primary : colors.backgroundAlt,
                      backgroundColor: showExplanation
                        ? (idx === current.correctIndex ? '#E8F5E9' : (isSelected ? '#FFEBEE' : colors.backgroundAlt))
                        : (isSelected ? '#E3F2FD' : colors.backgroundAlt),
                      boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={[commonStyles.text, { color: colors.text, textAlign: 'left', flex: 1 }]}>{current.options[idx]}</Text>
                    {feedback ? <Text style={[commonStyles.text, { marginBottom: 0 }]}>{feedback}</Text> : null}
                  </TouchableOpacity>
                );
              })}

              <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}>
                <TouchableOpacity
                  onPress={useFifty}
                  disabled={!lifelines.fifty || showExplanation}
                  style={{
                    flex: 1,
                    padding: 10,
                    borderRadius: 10,
                    backgroundColor: !lifelines.fifty || showExplanation ? '#CFD8DC' : colors.backgroundAlt,
                    alignItems: 'center',
                    boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                  }}
                >
                  <Text style={[commonStyles.text, { marginBottom: 0 }]}>50–50</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={useSkip}
                  disabled={!lifelines.skip || showExplanation}
                  style={{
                    flex: 1,
                    padding: 10,
                    borderRadius: 10,
                    backgroundColor: !lifelines.skip || showExplanation ? '#CFD8DC' : colors.backgroundAlt,
                    alignItems: 'center',
                    boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                  }}
                >
                  <Text style={[commonStyles.text, { marginBottom: 0 }]}>Skip</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setShowExplanation(true)}
                  disabled={!lifelines.hint || showExplanation}
                  style={{
                    flex: 1,
                    padding: 10,
                    borderRadius: 10,
                    backgroundColor: !lifelines.hint || showExplanation ? '#CFD8DC' : colors.backgroundAlt,
                    alignItems: 'center',
                    boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                  }}
                >
                  <Text style={[commonStyles.text, { marginBottom: 0 }]}>Hint</Text>
                </TouchableOpacity>
              </View>

              {!showExplanation ? (
                <TouchableOpacity
                  onPress={onConfirm}
                  disabled={selected === null}
                  style={{
                    padding: 12,
                    borderRadius: 10,
                    backgroundColor: selected === null ? '#B0BEC5' : colors.primary,
                    alignItems: 'center',
                    marginTop: 12,
                    boxShadow: '0px 2px 6px rgba(0,0,0,0.08)',
                  }}
                >
                  <Text style={{ color: 'white', fontWeight: '700' }}>Check Answer</Text>
                </TouchableOpacity>
              ) : (
                <>
                  {lifelines.hint && (
                    <Text style={[commonStyles.text, { marginTop: 10, textAlign: 'left', color: colors.grey }]}>
                      Hint: {current.hint || 'Think it through!'}
                    </Text>
                  )}
                  <Text style={[commonStyles.text, { marginTop: 8, textAlign: 'left', color: colors.grey }]}>
                    Explanation: {current.explanation}
                  </Text>
                  <TouchableOpacity
                    onPress={() => {
                      setLifelines(prev => ({ ...prev, hint: false }));
                      onNext();
                    }}
                    style={{
                      padding: 12,
                      borderRadius: 10,
                      backgroundColor: colors.primary,
                      alignItems: 'center',
                      marginTop: 12,
                      boxShadow: '0px 2px 6px rgba(0,0,0,0.08)',
                    }}
                  >
                    <Text style={{ color: 'white', fontWeight: '700' }}>
                      {answers.length + 1 >= totalPlanned ? 'Finish' : 'Next'}
                    </Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          ) : (
            <View style={{ padding: 16 }}>
              <Text style={[commonStyles.text]}>Preparing your quiz...</Text>
            </View>
          )}
          <View style={{ height: 40 }} />
        </ScrollView>
      )}
    </View>
  );
}
