
import { useLocalSearchParams, router } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  Platform,
  Alert,
  Linking,
} from 'react-native';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView } from '@gorhom/bottom-sheet';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import Icon from '../../../components/Icon';
import Button from '../../../components/Button';
import { colors, commonStyles, buttonStyles } from '../../../styles/commonStyles';
import { courseById, getTopicsForCourse, CourseTopic } from '../../../types/course';
import { useNotes } from '../../../hooks/useNotes';
import { ContentBlock } from '../../../types/note';
import { useAuth } from '../../../hooks/useAuth';

export default function CourseNotesScreen() {
  const { course, topic } = useLocalSearchParams<{ course: string; topic?: string }>();
  console.log('Notes route params:', { course, topic });
  const courseObj = courseById(course || '');
  const [textDraft, setTextDraft] = useState('');
  const bottomSheetRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ['1%', '40%'], []);
  const { userId } = useAuth();
  const {
    loading,
    note,
    loadNoteForCourse,
    appendTextBlock,
    appendImageBlock,
    appendFileBlock,
    syncingMessage,
    supabaseConfigured,
  } = useNotes();

  useEffect(() => {
    loadNoteForCourse(courseObj.id, topic);
  }, [courseObj.id, topic, loadNoteForCourse]);

  const topics = useMemo(() => getTopicsForCourse(courseObj.id), [courseObj.id]);
  const sections = useMemo(() => {
    const map = new Map<string, CourseTopic[]>();
    topics.forEach((t) => {
      if (!map.has(t.section)) map.set(t.section, []);
      map.get(t.section)!.push(t);
    });
    return Array.from(map.entries());
  }, [topics]);

  const selectedTopicObj = useMemo(() => {
    if (!topic) return null;
    const key = topic.toString().toLowerCase();
    return topics.find((t) => t.key === key) || null;
  }, [topic, topics]);

  const openSheet = () => bottomSheetRef.current?.expand();
  const closeSheet = () => bottomSheetRef.current?.close();

  const onAddText = async () => {
    if (!textDraft.trim()) {
      console.log('Nothing to add');
      return;
    }
    await appendTextBlock(courseObj.id, textDraft.trim(), topic);
    setTextDraft('');
    closeSheet();
  };

  const onPickImage = async () => {
    try {
      if (Platform.OS !== 'web') {
        const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!perm.granted) {
          Alert.alert('Permission needed', 'Please allow photo library access to attach images.');
          return;
        }
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
      });
      if (!result.canceled && result.assets && result.assets[0]) {
        const asset = result.assets[0];
        const fileName = (asset as any).fileName || (asset as any).filename || `image-${Date.now()}.jpg`;
        await appendImageBlock(courseObj.id, { uri: asset.uri, fileName }, topic);
        closeSheet();
      }
    } catch (e) {
      console.log('onPickImage error', e);
      Alert.alert('Image error', 'Failed to add image. Please try again.');
    }
  };

  const onPickFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        multiple: false,
        copyToCacheDirectory: true,
      });
      // Support new return shape { canceled, assets } and older shape { type: 'success' }
      const isSuccessNew = (result as any).canceled === false && Array.isArray((result as any).assets) && (result as any).assets.length > 0;
      const isSuccessOld = (result as any).type === 'success';
      if (isSuccessNew || isSuccessOld) {
        const payload = isSuccessNew ? (result as any) : { assets: [(result as any)] };
        const asset = payload.assets[0];
        await appendFileBlock(courseObj.id, asset, topic);
        closeSheet();
      } else if ((result as any).canceled) {
        // user canceled; nothing to do
      } else {
        console.log('Unknown document picker state', result);
      }
    } catch (e) {
      console.log('onPickFile error', e);
      Alert.alert('File error', 'Failed to add file. Please try again.');
    }
  };

  const navigateToTopic = (t?: string) => {
    if (!t) {
      router.replace({ pathname: `/course/${courseObj.id}/notes` });
      return;
    }
    router.replace({ pathname: `/course/${courseObj.id}/notes`, params: { topic: t } });
  };

  const openUrl = async (url?: string | null) => {
    if (!url) return;
    try {
      if (Platform.OS === 'web') {
        window.open(url, '_blank');
      } else {
        const supported = await Linking.canOpenURL(url);
        if (supported) {
          await Linking.openURL(url);
        } else {
          Alert.alert('Cannot open link', url);
        }
      }
    } catch (e) {
      console.log('openUrl error', e);
      Alert.alert('Open error', 'Could not open the attachment.');
    }
  };

  const Header = () => (
    <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
      <TouchableOpacity
        onPress={() => router.back()}
        style={{
          paddingHorizontal: 12,
          paddingVertical: 8,
          borderRadius: 8,
          backgroundColor: colors.backgroundAlt,
          boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
        }}
      >
        <Icon name="chevron-back" size={22} color={colors.text} />
      </TouchableOpacity>
      <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>
        {courseObj.name} {selectedTopicObj ? `• ${selectedTopicObj.title}` : 'Notes'}
      </Text>

      {userId ? (
        <View style={{ display: 'contents' }}>
          <View
            style={{
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderRadius: 8,
              backgroundColor: colors.backgroundAlt,
              boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
            }}
          >
            <Text style={{ color: colors.text, fontWeight: '700' }}>Logged in</Text>
          </View>
        </View>
      ) : (
        <TouchableOpacity
          onPress={() => router.push('/auth')}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.primary,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Text style={{ color: 'white', fontWeight: '700' }}>Login</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  const Banner = () => (
    <View>
      {!supabaseConfigured ? (
        <View style={{ marginHorizontal: 16, marginBottom: 8, padding: 10, backgroundColor: '#FFF8E1', borderRadius: 8, boxShadow: '0px 1px 2px rgba(0,0,0,0.08)' }}>
          <Text style={{ color: '#6D4C41', fontSize: 13 }}>
            To sync notes and upload attachments, enable Supabase by pressing the Supabase button in Natively and connecting to your project.
          </Text>
        </View>
      ) : null}
      {!userId ? (
        <View style={{ marginHorizontal: 16, marginBottom: 8, padding: 10, backgroundColor: '#E3F2FD', borderRadius: 8 }}>
          <Text style={{ color: colors.text, fontSize: 13 }}>
            Login to sync your notes across devices and upload attachments securely.
          </Text>
        </View>
      ) : null}
    </View>
  );

  const Syncing = () => (
    syncingMessage ? (
      <View style={{ marginHorizontal: 16, marginBottom: 8, padding: 8, backgroundColor: colors.backgroundAlt, borderRadius: 8 }}>
        <Text style={{ color: colors.text, fontSize: 12 }}>{syncingMessage}</Text>
      </View>
    ) : null
  );

  const TopicChip = ({ label, active, onPress }: { label: string; active?: boolean; onPress: () => void }) => (
    <TouchableOpacity
      onPress={onPress}
      style={{
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 999,
        backgroundColor: active ? colors.primary : colors.backgroundAlt,
        marginRight: 8,
        marginBottom: 10,
        boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
      }}
    >
      <Text style={{ color: active ? '#FFFFFF' : colors.text, fontWeight: '700', fontSize: 13 }}>{label}</Text>
    </TouchableOpacity>
  );

  const TopicsSection = () => (
    <View style={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
        <Icon name="book-outline" size={18} color={colors.secondary} />
        <Text style={[commonStyles.text, { marginLeft: 6, color: colors.grey, marginBottom: 0, textAlign: 'left' }]}>
          Topics
        </Text>
        <View style={{ flex: 1 }} />
        {selectedTopicObj ? (
          <TouchableOpacity
            onPress={() => navigateToTopic(undefined)}
            style={{
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: 8,
              backgroundColor: colors.backgroundAlt,
              boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
            }}
          >
            <Text style={{ color: colors.text, fontWeight: '700', fontSize: 12 }}>Clear</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {sections.map(([sectionName, list]) => (
        <View key={sectionName} style={{ marginBottom: 8 }}>
          <Text style={[commonStyles.text, { textAlign: 'left', color: colors.text, fontWeight: '800', marginBottom: 8 }]}>
            {sectionName}
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {list.map((t) => (
              <TopicChip
                key={t.key}
                label={t.title}
                active={selectedTopicObj?.key === t.key}
                onPress={() => navigateToTopic(t.key)}
              />
            ))}
          </View>
        </View>
      ))}
    </View>
  );

  const renderBlock = (block: ContentBlock, idx: number) => {
    if (block.type === 'text') {
      return (
        <View
          key={idx}
          style={{
            backgroundColor: colors.card,
            borderRadius: 12,
            padding: 12,
            marginBottom: 10,
            boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
          }}
        >
          <Text style={[commonStyles.text, { textAlign: 'left' }]}>{block.text}</Text>
        </View>
      );
    }
    if (block.type === 'image') {
      return (
        <View
          key={idx}
          style={{
            backgroundColor: colors.card,
            borderRadius: 12,
            padding: 10,
            marginBottom: 10,
            alignItems: 'center',
            boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
          }}
        >
          <Image
            source={{ uri: block.url }}
            style={{ width: '100%', height: 190, borderRadius: 10, backgroundColor: colors.backgroundAlt }}
            resizeMode="cover"
          />
          {block.name ? (
            <Text style={[commonStyles.text, { marginTop: 8, fontSize: 12, color: colors.grey }]}>{block.name}</Text>
          ) : null}
        </View>
      );
    }
    if (block.type === 'file') {
      return (
        <View
          key={idx}
          style={{
            backgroundColor: colors.card,
            borderRadius: 12,
            padding: 12,
            marginBottom: 10,
            flexDirection: 'row',
            alignItems: 'center',
            boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
          }}
        >
          <Icon name="document-attach" size={24} color={colors.secondary} />
          <View style={{ marginLeft: 10, flex: 1 }}>
            <Text style={[commonStyles.text, { textAlign: 'left' }]} numberOfLines={2}>{block.name || 'Attachment'}</Text>
            <Text style={{ fontSize: 12, color: colors.grey }} numberOfLines={1}>
              {block.url}
            </Text>
          </View>
          <TouchableOpacity onPress={() => openUrl(block.url)}>
            <Icon name="open-outline" size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>
      );
    }
    return null;
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Header />
      <Banner />
      <TopicsSection />
      <Syncing />
      {loading ? (
        <View style={[commonStyles.container, { justifyContent: 'center', alignItems: 'center' }]}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <ScrollView style={{ flex: 1, paddingHorizontal: 16 }}>
          <View style={{ height: 4 }} />
          {!note || note.blocks.length === 0 ? (
            <View
              style={{
                padding: 16,
                backgroundColor: colors.card,
                borderRadius: 12,
                alignItems: 'center',
                boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              }}
            >
              <Text style={[commonStyles.text, { color: colors.grey, textAlign: 'center' }]}>
                No notes yet for {selectedTopicObj ? `${selectedTopicObj.title}` : courseObj.name}. Tap Add to insert text, images, or files.
              </Text>
            </View>
          ) : null}

          {note?.blocks.map((b, idx) => renderBlock(b, idx))}
          <View style={{ height: 120 }} />
        </ScrollView>
      )}

      {/* Floating Add Button */}
      <TouchableOpacity
        onPress={openSheet}
        accessibilityLabel="Add content"
        style={{
          position: 'absolute',
          right: 20,
          bottom: 30,
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: colors.primary,
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0px 6px 16px rgba(0,0,0,0.2)',
        }}
        activeOpacity={0.85}
      >
        <Icon name="add" size={28} color="#FFFFFF" />
      </TouchableOpacity>

      <BottomSheet
        ref={bottomSheetRef}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backdropComponent={(props) => <BottomSheetBackdrop {...props} appearsOnIndex={1} disappearsOnIndex={-1} />}
      >
        <BottomSheetView style={{ padding: 16 }}>
          <Text style={[commonStyles.title, { fontSize: 18, marginBottom: 12 }]}>Insert</Text>

          <View style={{ marginBottom: 12 }}>
            <Text style={[commonStyles.text, { marginBottom: 6, textAlign: 'left' }]}>Text</Text>
            <TextInput
              placeholder={selectedTopicObj ? `Add note to ${selectedTopicObj.title}...` : 'Type your note...'}
              placeholderTextColor="#999"
              value={textDraft}
              onChangeText={setTextDraft}
              multiline
              style={{
                backgroundColor: colors.backgroundAlt,
                color: colors.text,
                borderRadius: 10,
                padding: 12,
                minHeight: 80,
                boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
              }}
            />
            <Button text="Add Text" onPress={onAddText} style={[buttonStyles.instructionsButton, { marginTop: 10 }]} />
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
            <TouchableOpacity
              onPress={onPickImage}
              style={{
                flex: 1,
                backgroundColor: colors.card,
                padding: 14,
                borderRadius: 10,
                alignItems: 'center',
                boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
              }}
            >
              <Icon name="image-outline" size={24} color={colors.secondary} />
              <Text style={[commonStyles.text, { marginTop: 6 }]}>Add Image</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={onPickFile}
              style={{
                flex: 1,
                backgroundColor: colors.card,
                padding: 14,
                borderRadius: 10,
                alignItems: 'center',
                boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
              }}
            >
              <Icon name="document-text-outline" size={24} color={colors.secondary} />
              <Text style={[commonStyles.text, { marginTop: 6 }]}>Add File</Text>
            </TouchableOpacity>
          </View>

          {!userId && (
            <View style={{ marginTop: 12, backgroundColor: '#FFF3E0', padding: 10, borderRadius: 8 }}>
              <Text style={{ color: '#6D4C41', fontSize: 12 }}>
                Tip: Login to upload and sync attachments to the cloud. You can still save locally without logging in.
              </Text>
            </View>
          )}
        </BottomSheetView>
      </BottomSheet>
    </View>
  );
}
