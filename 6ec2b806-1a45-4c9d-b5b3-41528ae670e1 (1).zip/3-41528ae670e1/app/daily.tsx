
import { router } from 'expo-router';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { colors, commonStyles } from '../styles/commonStyles';
import { courses } from '../types/course';
import Icon from '../components/Icon';

export default function DailyScreen() {
  const today = new Date().toDateString();

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderRadius: 8,
              backgroundColor: colors.backgroundAlt,
              boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
            }}
          >
            <Icon name="chevron-back" size={22} color={colors.text} />
          </TouchableOpacity>
          <Text style={[commonStyles.title, { marginLeft: 12, flex: 1, textAlign: 'left' }]}>
            Daily Study Challenge
          </Text>
        </View>
        <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>{today}</Text>

        <View style={{ height: 10 }} />

        {courses.map((c) => (
          <TouchableOpacity
            key={c.id}
            onPress={() => router.push(`/course/${encodeURIComponent(c.id)}/quiz?mode=daily`)}
            style={{
              backgroundColor: colors.card,
              borderRadius: 12,
              padding: 16,
              marginBottom: 12,
              boxShadow: '0px 2px 8px rgba(0,0,0,0.06)',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <View style={{ display: 'contents' }}>
              <Icon name={c.icon || 'book-outline'} size={26} color={colors.secondary} />
            </View>
            <Text style={[commonStyles.text, { flex: 1, marginLeft: 10, textAlign: 'left' }]}>{c.name}</Text>
            <View style={{ backgroundColor: colors.backgroundAlt, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 }}>
              <Text style={[commonStyles.text, { marginBottom: 0 }]}>Start</Text>
            </View>
          </TouchableOpacity>
        ))}

        <View style={{ height: 20 }} />
        <Text style={[commonStyles.text, { textAlign: 'center', fontSize: 12, color: colors.grey }]}>
          Each challenge is 5 adaptive questions per course. Good luck!
        </Text>
      </View>
    </ScrollView>
  );
}
