
import { useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { courses } from '../types/course';
import { useAuth } from '../hooks/useAuth';
import { useGamification } from '../hooks/useGamification';

export default function LearningPathScreen() {
  const { userId } = useAuth();
  const { sessions, recommendNextTopic } = useGamification(userId || null);

  const summaries = useMemo(() => {
    return courses.map(c => {
      // last session summary
      const last = sessions.find(s => s.course === c.id);
      const acc = last ? Math.round((last.accuracy || 0) * 100) : null;
      return {
        id: c.id,
        name: c.name,
        icon: c.icon,
        recommendation: recommendNextTopic(c.id as any),
        lastAcc: acc,
      };
    });
  }, [sessions, recommendNextTopic]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderRadius: 8,
              backgroundColor: colors.backgroundAlt,
              boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
            }}
          >
            <Icon name="chevron-back" size={22} color={colors.text} />
          </TouchableOpacity>
          <Text style={[commonStyles.title, { marginLeft: 12, flex: 1, textAlign: 'left' }]}>
            Learning Path
          </Text>
        </View>

        {summaries.map(s => (
          <View key={s.id} style={{ backgroundColor: colors.card, borderRadius: 12, padding: 14, marginBottom: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
              <Icon name={s.icon || 'book-outline'} size={22} color={colors.secondary} />
              <Text style={[commonStyles.title, { marginLeft: 8, textAlign: 'left' }]}>{s.name}</Text>
            </View>
            {s.lastAcc !== null ? (
              <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>
                Last accuracy: {s.lastAcc}%
              </Text>
            ) : (
              <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>
                No history yet. Start with a quiz!
              </Text>
            )}
            <Text style={[commonStyles.text, { textAlign: 'left', marginTop: 6 }]}>
              Next: {s.recommendation}
            </Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <TouchableOpacity
                onPress={() => router.push(`/course/${encodeURIComponent(s.id)}/notes`)}
                style={{
                  flex: 1,
                  padding: 12,
                  borderRadius: 10,
                  backgroundColor: colors.backgroundAlt,
                  alignItems: 'center',
                  boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                }}
              >
                <Text style={[commonStyles.text, { marginBottom: 0 }]}>Open Notes</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => router.push(`/course/${encodeURIComponent(s.id)}/quiz`)}
                style={{
                  flex: 1,
                  padding: 12,
                  borderRadius: 10,
                  backgroundColor: colors.primary,
                  alignItems: 'center',
                  boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
                }}
              >
                <Text style={{ color: '#fff', fontWeight: '700' }}>Start Quiz</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}
