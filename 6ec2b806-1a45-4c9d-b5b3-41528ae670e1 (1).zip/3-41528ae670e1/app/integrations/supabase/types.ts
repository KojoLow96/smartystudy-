
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type UserCourseNoteRow = {
  id: string
  user_id: string
  course: 'mathematics' | 'science' | 'history'
  blocks: Json
  created_at: string
  updated_at: string
}

export type UserTopicNoteRow = {
  id: string
  user_id: string
  course: 'mathematics' | 'science' | 'history'
  topic: string
  blocks: Json
  created_at: string
  updated_at: string
}

export type Database = {
  public: {
    Tables: {
      user_course_notes: {
        Row: UserCourseNoteRow
        Insert: {
          id?: string
          user_id: string
          course: UserCourseNoteRow['course']
          blocks?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          course?: UserCourseNoteRow['course']
          blocks?: Json
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'user_course_notes_user_id_fkey',
            columns: ['user_id'],
            referencedRelation: 'users',
            referencedColumns: ['id']
          }
        ]
      },
      user_topic_notes: {
        Row: UserTopicNoteRow
        Insert: {
          id?: string
          user_id: string
          course: UserTopicNoteRow['course']
          topic: string
          blocks?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          course?: UserTopicNoteRow['course']
          topic?: string
          blocks?: Json
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'user_topic_notes_user_id_fkey',
            columns: ['user_id'],
            referencedRelation: 'users',
            referencedColumns: ['id']
          }
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: Record<string, never>
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database['public']

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
