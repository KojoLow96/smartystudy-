
import { supabase } from './client';

// Lightweight availability check using a public-readable table if it exists.
// Returns true only if we can successfully execute a select without errors.
// If the schema isn't set up yet, this will return false.
export async function isSupabaseAvailable(): Promise<boolean> {
  try {
    // Try selecting from a tiny leaderboard table. This is inexpensive and works with anon key
    // if the table exists and has RLS that allows public read.
    const { error } = await supabase
      .from('user_points')
      .select('user_id')
      .limit(1);
    if (error) {
      console.log('isSupabaseAvailable: select failed', error.message);
      return false;
    }
    return true;
  } catch (e) {
    console.log('isSupabaseAvailable exception', e);
    return false;
  }
}
