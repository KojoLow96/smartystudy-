
import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Database } from './types';
import { createClient } from '@supabase/supabase-js'

// NOTE: Please enable Supabase by pressing the Supabase button in Natively and connecting to your project.
// After connecting, these values will be provided automatically.
const SUPABASE_URL = "https://wpxkiohcsspmyclnpoty.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndweGtpb2hjc3NwbXljbG5wb3R5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQxODEyNjIsImV4cCI6MjA2OTc1NzI2Mn0.6zuiTBCypwiu8XnkaX2FKda529Z3yPpJnHBdDM41758";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    // Enable URL detection for web OAuth so returning from the provider works seamlessly.
    // On native, we use exchangeCodeForSession via openAuthSession, so this won’t interfere.
    detectSessionInUrl: true,
  },
})
