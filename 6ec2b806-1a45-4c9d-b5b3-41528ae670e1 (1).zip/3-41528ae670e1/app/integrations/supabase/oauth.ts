
import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import { Platform } from 'react-native';
import { supabase } from './client';

type OAuthProvider = 'github';

export async function signInWithProvider(provider: OAuthProvider) {
  try {
    // Create a deep link that comes back into the app
    const redirectTo = Linking.createURL('auth-callback');

    if (Platform.OS === 'web') {
      // On web, let Supabase handle the redirect in current tab
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
      });
      if (error) throw error;
      return null;
    }

    // On native, open an auth session and then exchange the code for a session
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        skipBrowserRedirect: true,
        redirectTo,
      } as any,
    });

    if (error) throw error;
    if (!data?.url) {
      throw new Error('No authorization URL returned from Supabase.');
    }

    const result = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);

    if (result.type === 'success' && result.url) {
      // Parse the redirect URL for either error or "code"
      const parsed = Linking.parse(result.url);
      const code = (parsed.queryParams?.code as string) || '';
      const error_description = parsed.queryParams?.error_description as string | undefined;

      if (error_description) {
        throw new Error(decodeURIComponent(error_description));
      }
      if (!code) {
        throw new Error('No authorization code returned.');
      }

      const { data: sessionData, error: exchangeErr } = await supabase.auth.exchangeCodeForSession(code);
      if (exchangeErr) throw exchangeErr;
      return sessionData?.session ?? null;
    }

    throw new Error('Authentication canceled.');
  } catch (e) {
    console.log('signInWithProvider error', e);
    throw e;
  }
}

export async function signInWithGitHub() {
  return signInWithProvider('github');
}
