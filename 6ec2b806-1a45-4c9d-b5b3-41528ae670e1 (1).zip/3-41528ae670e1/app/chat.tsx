
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import Icon from '../components/Icon';
import { colors, commonStyles } from '../styles/commonStyles';
import { supabase } from './integrations/supabase/client';

type ChatMsg = { role: 'user' | 'assistant'; content: string };

export default function ChatScreen() {
  const [messages, setMessages] = useState<ChatMsg[]>([
    { role: 'assistant', content: 'Hello! I am your SmartStudy AI. Ask me anything related to Mathematics, Science, or History.' },
  ]);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    scrollRef.current?.scrollToEnd({ animated: true });
  }, [messages.length]);

  const send = useCallback(async () => {
    if (loading) return;
    const text = draft.trim();
    if (!text) return;
    const next = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setDraft('');
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-chat', {
        body: {
          system: 'You are SmartStudy AI assistant. Be concise, helpful, and explain step-by-step as needed.',
          messages: next.map(m => ({ role: m.role, content: m.content })),
        },
      });
      if (error) {
        console.log('chat error', error);
        setMessages(prev => [...prev, { role: 'assistant', content: 'I could not reach the AI. Please ensure Supabase integration is enabled in Natively and your OpenAI key is configured in the Edge Function.' }]);
      } else if ((data as any)?.text) {
        setMessages(prev => [...prev, { role: 'assistant', content: String((data as any).text) }]);
      } else {
        setMessages(prev => [...prev, { role: 'assistant', content: 'No response. Try again later.' }]);
      }
    } catch (e) {
      console.log('chat exception', e);
      setMessages(prev => [...prev, { role: 'assistant', content: 'There was an error. Please enable Supabase in Natively and try again.' }]);
    } finally {
      setLoading(false);
    }
  }, [draft, messages, loading]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.backgroundAlt,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Icon name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>AI Chat</Text>
      </View>

      <ScrollView ref={scrollRef} style={{ flex: 1, paddingHorizontal: 16 }}>
        {messages.map((m, idx) => {
          const isUser = m.role === 'user';
          return (
            <View
              key={idx}
              style={{
                alignSelf: isUser ? 'flex-end' : 'flex-start',
                backgroundColor: isUser ? colors.primary : colors.card,
                padding: 12,
                borderRadius: 12,
                maxWidth: '85%',
                marginVertical: 6,
                boxShadow: '0px 2px 6px rgba(0,0,0,0.08)',
              }}
            >
              <Text style={[commonStyles.text, { color: isUser ? 'white' : colors.text, textAlign: 'left', marginBottom: 0 }]}>{m.content}</Text>
            </View>
          );
        })}
        {loading ? (
          <View style={{ paddingVertical: 10 }}>
            <ActivityIndicator color={colors.primary} />
          </View>
        ) : null}
        <View style={{ height: 20 }} />
      </ScrollView>

      <View style={{ padding: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <TextInput
          placeholder="Ask SmartStudy AI..."
          placeholderTextColor="#999"
          value={draft}
          onChangeText={setDraft}
          editable={!loading}
          style={{
            flex: 1,
            backgroundColor: colors.backgroundAlt,
            color: colors.text,
            borderRadius: 10,
            paddingHorizontal: 12,
            paddingVertical: 10,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
            opacity: loading ? 0.7 : 1,
          }}
        />
        <TouchableOpacity
          onPress={send}
          disabled={loading}
          style={{
            paddingHorizontal: 14,
            paddingVertical: 10,
            borderRadius: 10,
            backgroundColor: loading ? '#B0BEC5' : colors.primary,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Text style={{ color: 'white', fontWeight: '700' }}>{loading ? 'Sending...' : 'Send'}</Text>
        </TouchableOpacity>
      </View>

      <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
        <Text style={[commonStyles.text, { textAlign: 'center', fontSize: 12, color: colors.grey }]}>
          Tip: Enable Supabase in Natively and set your OpenAI API key in the Edge Function.
        </Text>
      </View>
    </View>
  );
}
