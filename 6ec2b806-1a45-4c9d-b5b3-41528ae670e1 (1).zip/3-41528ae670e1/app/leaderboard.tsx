
import { useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { useAuth } from '../hooks/useAuth';
import { useGamification } from '../hooks/useGamification';

export default function LeaderboardScreen() {
  const { userId } = useAuth();
  const { leaderboard, fetchLeaderboard, supabaseConfigured } = useGamification(userId || null);

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              paddingHorizontal: 12,
              paddingVertical: 8,
              borderRadius: 8,
              backgroundColor: colors.backgroundAlt,
              boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
            }}
          >
            <Icon name="chevron-back" size={22} color={colors.text} />
          </TouchableOpacity>
          <Text style={[commonStyles.title, { marginLeft: 12, flex: 1, textAlign: 'left' }]}>
            Leaderboard
          </Text>
        </View>

        {!supabaseConfigured ? (
          <View style={{ padding: 12, backgroundColor: '#FFF8E1', borderRadius: 10, marginBottom: 12 }}>
            <Text style={{ color: '#6D4C41', fontSize: 13 }}>
              Enable Supabase in Natively to view the global leaderboard. You can still earn points locally.
            </Text>
          </View>
        ) : null}

        {leaderboard.length === 0 ? (
          <View style={{ padding: 16, backgroundColor: colors.card, borderRadius: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
            <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>
              No leaderboard data yet. Start completing quizzes to earn points!
            </Text>
          </View>
        ) : (
          <View style={{ backgroundColor: colors.card, borderRadius: 12, padding: 10, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
            {leaderboard.map((row, idx) => (
              <View
                key={row.user_id + idx}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingVertical: 10,
                  borderBottomWidth: idx < leaderboard.length - 1 ? 1 : 0,
                  borderBottomColor: '#ECEFF1',
                }}
              >
                <Text style={[commonStyles.text, { textAlign: 'left' }]}>
                  #{idx + 1} User {row.user_id.slice(0, 6)}...
                </Text>
                <Text style={[commonStyles.text, { textAlign: 'right' }]}>{row.points} pts</Text>
              </View>
            ))}
          </View>
        )}
      </View>
    </ScrollView>
  );
}
