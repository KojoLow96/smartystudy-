
import { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Switch, Platform } from 'react-native';
import { router } from 'expo-router';
import DateTimePicker from '@react-native-community/datetimepicker';
import { colors, commonStyles } from '../styles/commonStyles';
import Icon from '../components/Icon';
import { cancelAllReminders, loadReminderSettings, scheduleDailyReminder } from '../utils/notifications';

export default function SettingsScreen() {
  const [enabled, setEnabled] = useState(false);
  const [time, setTime] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await loadReminderSettings();
      setEnabled(s.enabled);
      const d = new Date();
      d.setHours(s.hour);
      d.setMinutes(s.minute);
      d.setSeconds(0);
      setTime(d);
    })();
  }, []);

  async function onSave() {
    setSaving(true);
    try {
      const hour = time.getHours();
      const minute = time.getMinutes();
      if (enabled) {
        await scheduleDailyReminder(hour, minute);
      } else {
        await cancelAllReminders();
      }
    } catch (e) {
      console.log('onSave settings error', e);
    } finally {
      setSaving(false);
    }
  }

  function onChangeTime(event: any, selected?: Date) {
    if (Platform.OS !== 'ios') setShowPicker(false);
    if (selected) {
      setTime(selected);
    }
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 8,
            backgroundColor: colors.backgroundAlt,
            boxShadow: '0px 1px 2px rgba(0,0,0,0.1)',
          }}
        >
          <Icon name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[commonStyles.title, { marginLeft: 12, flex: 1 }]}>Settings</Text>
      </View>

      <View style={{ padding: 16 }}>
        <View style={{ backgroundColor: colors.card, padding: 14, borderRadius: 12, boxShadow: '0px 2px 8px rgba(0,0,0,0.06)' }}>
          <Text style={[commonStyles.title, { textAlign: 'left' }]}>Study Reminder</Text>
          <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey }]}>
            Get a daily push notification to keep a consistent study habit.
          </Text>

          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 12, justifyContent: 'space-between' }}>
            <Text style={[commonStyles.text, { textAlign: 'left', marginBottom: 0 }]}>
              Enable Daily Reminder
            </Text>
            <Switch value={enabled} onValueChange={setEnabled} />
          </View>

          <View style={{ height: 10 }} />

          <TouchableOpacity
            onPress={() => setShowPicker(true)}
            disabled={!enabled}
            style={{
              padding: 12,
              borderRadius: 10,
              backgroundColor: enabled ? colors.backgroundAlt : '#CFD8DC',
              alignItems: 'center',
              boxShadow: '0px 1px 2px rgba(0,0,0,0.06)',
            }}
          >
            <Text style={[commonStyles.text, { marginBottom: 0 }]}>
              Time: {String(time.getHours()).padStart(2, '0')}:{String(time.getMinutes()).padStart(2, '0')}
            </Text>
          </TouchableOpacity>

          {showPicker && (
            <DateTimePicker
              value={time}
              mode="time"
              is24Hour
              onChange={onChangeTime}
            />
          )}

          <TouchableOpacity
            onPress={onSave}
            style={{
              padding: 12,
              borderRadius: 10,
              backgroundColor: colors.primary,
              alignItems: 'center',
              marginTop: 12,
              boxShadow: '0px 2px 6px rgba(0,0,0,0.08)',
            }}
          >
            <Text style={{ color: 'white', fontWeight: '700' }}>{saving ? 'Saving…' : 'Save Settings'}</Text>
          </TouchableOpacity>

          <Text style={[commonStyles.text, { textAlign: 'left', color: colors.grey, fontSize: 12, marginTop: 8 }]}>
            Notifications require app permissions. If you do not receive notifications, check your OS settings.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}
